#include"Queue.h"
int main()
{
	Queue Q(5);
	Q.EnQueue(1);
	Q.EnQueue(2);
	Q.EnQueue(3);
	Q.EnQueue(4);
	Q.EnQueue(5);
	Q.PrintQueue();
	cout << "Size of Queue:" << Q.Sizeof() << endl;

	cout << "DeQueue:" << Q.DeQueue() << endl;
	cout << "DeQueue:" << Q.DeQueue() << endl;
	cout << "Size of Queue:" << Q.Sizeof() << endl;
	Q.PrintQueue();
	return 0;
}