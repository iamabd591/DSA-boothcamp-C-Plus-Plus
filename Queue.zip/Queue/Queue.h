#pragma once
#include<iostream>
using namespace std;
class Queue
{
	int* arr;
	int size;
	int front;
	int rear;
	int count;
public:
	Queue();
	Queue(int);
	void EnQueue(int);
	int DeQueue();
	bool IsFull();
	bool IsEmpty();
	int Sizeof();
	void PrintQueue();
	~Queue();
};

