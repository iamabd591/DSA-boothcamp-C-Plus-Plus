#include "Queue.h"
Queue::Queue() {
	this->arr = nullptr;
	this->size = 0;
	this->front = 0;
	this->rear = 0;
	this->count = 0;
}
Queue::Queue(int s) {
	this->size = s;
	this->front = -1, this->rear = -1, this->count = -1;
	this->arr = new int[this->size];
}
void Queue::EnQueue(int value) {
	if (IsFull())
	{
		cout << "Queue is Full" << endl;
	}
	else
	{
		if (this->front==-1)
		{
			this->front = 0;
			this->rear++;
			this->arr[this->rear] = value;
			this->count++;
		}
		else
		{
			if (this->rear != this->size - 1)
			{
				this->rear++;
				this->arr[this->rear] = value;
				this->count++;
			}
		}
	}
}
int Queue::DeQueue() {
	int value = 0;
	if (IsEmpty())
	{
		cout << "Queue is Empty" << endl;
		return 0;
	}
	else
	{
		if (this->front == this->rear)
		{
			this->front = -1;
			this->rear = -1;
		}
		else
		{
			value = this->arr[this->front]; 
			this->front++;
			this->count--;
		}
		return value;
	}

}

bool Queue::IsFull() {
	if (this->front == 0 && this->rear == this->size - 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Queue::IsEmpty() {
	if (this->front == -1 && this->rear == -1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int Queue::Sizeof() {
	return this->count + 1;
}
void Queue::PrintQueue() {
	cout << "Queue Data:";
	for (int i = this->front; i < this->rear + 1; i++)
	{
		cout << this->arr[i] << " ";
	}
	cout << endl;
}
Queue::~Queue() {
	if (this->arr != nullptr)
	{
		delete[] this->arr;
	}
}