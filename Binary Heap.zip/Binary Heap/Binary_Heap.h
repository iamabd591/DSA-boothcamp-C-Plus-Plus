#pragma once
#include<iostream>
using namespace std;
template <typename T>
class Binary_Heap
{
private:
	T* Arr;
	int capacity;
	int size;
public:
	Binary_Heap();
	Binary_Heap(int);
	void InsertMinHeapify(int);
	void InsertMaxHeapify(int);
	void MinHeapify(int);
	void MaxHeapify(int);
	void HeapSorted();
	int SumofHeap();
	int FindMax();
	int Find2Max();
	int FindMini();
	int Delete();
	void Display();
	int Parent(int);
	int LeftChild(int);
	int RightChild(int);
	int GetMin();
	~Binary_Heap();
};
template<typename T>
inline Binary_Heap<T>::Binary_Heap()
{
	this->Arr = nullptr;
	this->capacity = 0;
	this->size = 0;
}

template<typename T>
inline Binary_Heap<T>::Binary_Heap(int c)
{
	this->size = 0;
	this->capacity = c;
	this->Arr = new T[this->capacity];
}

template<typename T>
inline void Binary_Heap<T>::InsertMinHeapify(int value)
{
	if (this->size == this->capacity)
	{
		cout << "OverFlow! Could not Enter any more value";
		return;
	}
	else
	{
		this->Arr[this->size] = value;
		this->size++;
		int i = this->size - 1;
		while (i != 0 && this->Arr[this->Parent(i)] > this->Arr[i])
		{
			T temp = 0;
			temp = this->Arr[i];
			this->Arr[i] = this->Arr[this->Parent(i)];
			this->Arr[this->Parent(i)] = temp;
			i = this->Parent(i);

		}

	}
}
template<typename T>
inline void Binary_Heap<T>::InsertMaxHeapify(int value)
{
	if (this->size == this->capacity)
	{
		cout << "OverFlow! Could not Enter any more value";
		return;
	}
	else
	{
		this->Arr[this->size] = value;
		this->size++;
		int i = this->size - 1;
		while (i != 0 && this->Arr[this->Parent(i)] < this->Arr[i])
		{
			T temp = 0;
			temp = this->Arr[i];
			this->Arr[i] = this->Arr[this->Parent(i)];
			this->Arr[this->Parent(i)] = temp;
			i = this->Parent(i);

		}

	}
}
template<typename T>
inline void Binary_Heap<T>::Display()
{
	if (this->size == 0)
	{
		cout << "Binary Heap is Empty" << endl;
		return;
	}
	else
	{
		cout << "Binary Heap:";
		for (int i = 0; i < this->size; i++)
		{
			cout << this->Arr[i] << " ";
		}
		cout << endl;
	}
}
template<typename T>
inline int Binary_Heap<T>::Delete()
{
	int value = 0;
	if (this->size == 0)
	{
		cout << "Heap Binary is Empty" << endl;
		return value;
	}
	if (this->size == 1)
	{
		value = this->Arr[this->size];
		this->size--;
		return value;
	}
	else
	{
		int i = 0;
		value = this->Arr[0];
		this->Arr[0] = this->Arr[this->size - 1];
		this->size--;
		this->MinHeapify(i);
		return value;
	}
}

template<typename T>
inline void Binary_Heap<T>::MinHeapify(int i)
{
	int right = this->RightChild(i);
	int left = this->LeftChild(i);
	int smallest = i;
	int temp = 0;
	if (left < this->size && this->Arr[left] < this->Arr[i])
	{
		smallest = left;
	}
	if (right < this->size && this->Arr[right] < this->Arr[left])
	{
		smallest = right;
	}
	if (smallest != i)
	{
		temp = this->Arr[i];
		this->Arr[i] = this->Arr[smallest];
		this->Arr[smallest] = temp;
		MinHeapify(smallest);
	}
}
template<typename T>
inline void Binary_Heap<T>::MaxHeapify(int i)
{
	int right = this->RightChild(i);
	int left = this->LeftChild(i);
	int Greater = i;
	int temp = 0;
	if (left < this->size && this->Arr[left] > this->Arr[i])
	{
		Greater = left;
	}
	if (right < this->size && this->Arr[right] > this->Arr[left])
	{
		Greater = right;
	}
	if (Greater != i)
	{
		temp = this->Arr[i];
		this->Arr[i] = this->Arr[Greater];
		this->Arr[Greater] = temp;
		MaxHeapify(Greater);
	}
}
template<typename T>
inline void Binary_Heap<T>::HeapSorted()
{
	T temp = 0;
	for (int i = 0; i < this->size; i++)
	{
		for (int j = i; j < this->size; j++)
		{
			if (this->Arr[i] > this->Arr[j])
			{
				temp = this->Arr[j];
				this->Arr[j] = this->Arr[i];
				this->Arr[i] = temp;
			}
		}
	}
	cout << "Sorted Heap:";
	for (int i = 0; i < this->size; i++)
	{
		cout << this->Arr[i] << " ";
	}
	cout << endl;
}
template<typename T>
inline int Binary_Heap<T>::SumofHeap()
{
	int sum = 0;
	for (int i = 0; i < this->size; i++)
	{
		sum += this->Arr[i];
	}
	return sum;
}
template<typename T>
inline int Binary_Heap<T>::FindMax()
{
	int temp = this->Arr[0];
	for (int i = 0; i < this->size; i++)
	{
		if (this->Arr[i] > temp) {
			temp = this->Arr[i];
		}
	}
	return temp;
}
template<typename T>
inline int Binary_Heap<T>::Find2Max()
{
	int temp = this->FindMax();
	int second = this->Arr[0];
	for (int i = 0; i < this->size; i++)
	{
		if (this->Arr[i] > second && this->Arr[i]< temp)
		{
			second = this->Arr[i];
		}
	}
	return second;
}
template<typename T>
inline int Binary_Heap<T>::FindMini()
{
	int temp = this->Arr[0];
	for (int i = 0; i < this->size; i++)
	{
		if (this->Arr[i] < temp) {
			temp = this->Arr[i];
		}
	}
	return temp;
}
template<typename T>
inline int Binary_Heap<T>::Parent(int i)
{
	return (i - 1) / 2;
}

template<typename T>
inline int Binary_Heap<T>::LeftChild(int i)
{
	return (2 * i + 1);
}

template<typename T>
inline int Binary_Heap<T>::RightChild(int i)
{
	return (2 * i + 2);
}

template<typename T>
inline int Binary_Heap<T>::GetMin()
{
	return this->Arr[0];
}

template<typename T>
inline Binary_Heap<T>::~Binary_Heap()
{
	if (this->Arr != nullptr)
	{
		delete[] this->Arr;
	}
}