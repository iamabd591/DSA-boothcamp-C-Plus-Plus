#include<iostream>
#include"Binary_Heap.h"
using namespace std;
int main()
{
	Binary_Heap<int> b(10);
	int option = 0;
	cout << "Press 1 For Min Heapify:" << endl;
	cout << "Press 2 For Max Heapify:" << endl;
		cin >> option;
		if (option == 1)
		{
			b.InsertMinHeapify(10);
			b.InsertMinHeapify(20);
			b.InsertMinHeapify(19);
			b.InsertMinHeapify(21);
			b.InsertMinHeapify(27);
			b.InsertMinHeapify(30);
			b.InsertMinHeapify(35);
			b.InsertMinHeapify(5);
			b.InsertMinHeapify(15);
			b.InsertMinHeapify(23);
			b.Display();
			b.HeapSorted();
			cout << "Sum:" << b.SumofHeap() << endl;
			cout << "Maximum:" << b.FindMax() << endl;
			cout << "2-Maximum:" << b.Find2Max() << endl;
			cout << "Minimum:" << b.FindMini() << endl;
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
		}
		else if(option==2) {
			b.InsertMaxHeapify(10);
			b.InsertMaxHeapify(20);
			b.InsertMaxHeapify(19);
			b.InsertMaxHeapify(21);
			b.InsertMaxHeapify(27);
			b.InsertMaxHeapify(30);
			b.InsertMaxHeapify(35);
			b.InsertMaxHeapify(5);
			b.InsertMaxHeapify(15);
			b.InsertMaxHeapify(23);
			b.Display();
			b.HeapSorted();
			cout << "Sum:" << b.SumofHeap() << endl;
			cout << "Maximum:" << b.FindMax() << endl;
			cout << "2-Maximum:" << b.Find2Max() << endl;
			cout << "Minimum:" << b.FindMini() << endl;
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
			cout << "Delete Value:" << b.Delete() << endl;
			b.Display();
		}
		else
		{
			cout << "Invalid Value" << endl;
		}
	return 0;
}