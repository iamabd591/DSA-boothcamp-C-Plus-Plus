#pragma once
#include<iostream>
using namespace std;

class Queue
{
	int* arr;
	int size;
	int front;
	int rear;
public:
	Queue();
	Queue(int);
	bool isFull();
	bool isEmpty();
	void Enqueue(int);
	int Dequeue();
	int Peek();
	void display();
	~Queue();
};

