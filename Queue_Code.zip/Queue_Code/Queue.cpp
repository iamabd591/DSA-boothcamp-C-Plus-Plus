#include "Queue.h"
Queue::Queue() {
	this->arr = nullptr;
	this->size = 0;
	this->front = 0;
	this->rear = 0;
}
Queue::Queue(int s) {
	this->size = s;
	this->front = -1;
	this->rear = -1;
	this->arr = new int[this->size];
	for (int i = 0; i < this->size; i++)
	{
		this->arr[i] = i + 1;
		this->rear++;
	}
}
bool Queue::isFull() {
	if (this->front == 0 && this->rear == this->size-1)
	{
		return 1;
	}
}
bool Queue::isEmpty() {
	if (this->front==-1)
	{
		return 1;
	}
}
void Queue::Enqueue(int value) {
	if (isFull())
	{
		cout<<"Queue is Full"<<endl;
	}
	else
	{
		if(this->front==-1)
		this->front==0;
		this->rear++;
		this->arr[this->rear] = value;
	}
}
int Queue::Dequeue() {
	if (isEmpty())
	{
		cout<<"Queue is Empty"<<endl;
	}
	else
	{
		// return this->arr[this->front];
		if(this->front>=this->rear)
		{
			this->front=-1;
			this->rear=-1;
		}
		else
		{
			this->front++;
		}
		return this->arr[this->front];
	}
}
int Queue::Peek() {
	if (!isEmpty())
	{
		return this->arr[this->front];
	}
	else
	{
		cout << "Queue is Empty" << endl;
	}
}

void Queue::display() {
	for (int i = 0; i < this->size; i++)
	{
		cout << this->arr[i] << " ";
	}
}
Queue::~Queue() {
	if (this->arr != nullptr)
	{
		delete[] this->arr[];
	}
}