#include"Queue.h"
int main()
{
	Queue obj(5);
	int option = 0;
	int a = 0;
	do {
		cout << "-----------------------------------------" << endl;
		cout << "     Press 1 For Display        " << endl;
		cout << "     Press 2 For En-Queue       " << endl;
		cout << "     Press 3 For De-Queue       " << endl;
		cout << "     Press 4 For Queue is Full  " << endl;
		cout << "     Press 5 For Queue is Empty " << endl;
		cout << "     Press 6 For Peek Value     " << endl;
		cout << "     Press 7 For Exixt          " << endl;
		cout << "-----------------------------------------" << endl;
		cin >> option;

		switch (option)
		{
		case 1:
			cout << "Queue Values is:";
			obj.display();
			break;

		case 2:
			cout << "Enter Value For En-Queue:";
			cin >> a;
			obj.Enqueue(a);
			break;

		case 3:
			cout << "De-Queue Value is:" << obj.Dequeue();
			break;

		case 4:
			if (obj.isFull() == 1)
			{
				cout << "Queue is Full";
			}
			break;

		case 5:
			if (obj.isEmpty() == 1)
			{
				cout << "Queue is Empty";
			}
			break;

		case 6:
			cout << "Peek value Of Queue is:" << obj.Peek() << endl;
			break;

		case 7:
			exit(0);

		default:
			cout << "Invalid Value" << endl;
			break;
			break;
		}
	} 
	while (true);
	
}