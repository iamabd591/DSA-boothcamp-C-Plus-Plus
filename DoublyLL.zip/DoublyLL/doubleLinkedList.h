#pragma once
template <typename T>
class doubleLinkedList
{
public:
	virtual void Insert_at_first(T) = 0;
	virtual void Insert_at_last(T) = 0;
	virtual void Insert_at_position(T, int) = 0;
	virtual void Delete_at_first() = 0;
	virtual void Delete_at_last() = 0;
	virtual void Delete_from_position(T) = 0;
	virtual void Delete_Node(T) = 0;
	virtual void Insert_at_Mid(T) = 0;
};

