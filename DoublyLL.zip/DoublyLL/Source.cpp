#include"mydoubleLinkedList.h"
int main()
{
	mydoubleLinkedList<int> obj;
	int option = 0;
	int a = 0;
	int b = 0;
	do
	{
		cout << "Press->1 For Insert At First:" << endl;
		cout << "Press->2 For Insert At End:" << endl;
		cout << "Press->3 For Insert At Position:" << endl;
		cout << "Press->4 For Delete At First" << endl;
		cout << "Press->5 For Delete AT End" << endl;
		cout << "Press->6 For Delete From Positon"<< endl;
		cout << "press->7 For Delete Node" << endl;
		cout << "Press->8 For Search Node" << endl;
		cout << "Press->9 For Insert At Mid" << endl;
		cout << "Press->10 For Reverse" << endl;
		cout << "Press->11 For Sort" << endl;
		cout << "Press->12 For Sum" << endl;
		cout << "Press->13 For Swap" << endl;
		cout << "Press->14 For Delete duplicates" << endl;
		cout << "Press->15 For Exixt" << endl;
		cin >> option;
		switch (option)
		{
		case 1:
			cout << "Enter the Value:";
			cin >> a;
			obj.Insert_at_first(a);
			system("cls");
			obj.Display();
			break;

		case 2:
			cout << "Enter the Value:";
			cin >> a;
			obj.Insert_at_last(a);
			system("cls");
			obj.Display();
			break;

		case 3:
			cout << "Enter the Value & Position Respectively:";
			cin >> a;
			cin >> b;
			obj.Insert_at_position(a,b);
			system("cls");
			obj.Display();
			break;

		case 4:
			obj.Delete_at_first();
			system("cls");
			obj.Display();
			break;

		case 5:
			obj.Delete_at_last();
			system("cls");
			obj.Display();
			break;

		case 6:
			cout << "Enter the Position:";
			cin >> a;
			obj.Delete_from_position(a);
			system("cls");
			obj.Display();
			break;

		case 7:
			cout << "Enter the Node Value:";
			cin >> a;
			obj.Delete_Node(a);
			system("cls");
			obj.Display();
			break;

		case 8:
			cout << "Enter the Node value:";
			cin >> a;
			obj.Search(a);
			break;

		case 9:
			cout << "Enter the value:";
			cin >> a;
			obj.Insert_at_Mid(a);
			system("cls");
			obj.Display();
			break;

		case 10:
			obj.Reverse();
			system("cls");
			cout << "Reverse ";
			obj.Display();
			break;

		case 11:
			obj.sort();
			system("cls");
			cout << "Sorted ";
			obj.Display();
			break;

		case 12:
			cout << "Sum of Linked List: " << obj.sum() << endl;
			break;

		case 13:
			obj.Swap();
			system("cls");
			cout << "Swaped ";
			obj.Display();
			break;
		break; 


		case 14:
			obj.deleteDuplicates();
			system("cls");
			cout << "Duplicates Deleted";
			obj.Display();
			break;
			break;

		case 15:
			exit(0);
			break;
		default:
			cout << "Invalid Input" << endl;
			system("cls");
			break;
		}
	} while (true);
	return 0;

}