#pragma once
#include"doubleLinkedList.h"
#include<iostream>
using namespace std;
template <typename T>
class Node {
public:
	int value;
	Node* next;
	Node* previous;
	Node();
	Node(int);
};
template <typename T>
class mydoubleLinkedList :public doubleLinkedList <T>
{
protected:
	Node<T>* Head;
public:
	mydoubleLinkedList();
	virtual	void Insert_at_first(T);
	virtual	void Insert_at_last(T);
	virtual	void Insert_at_position(T, int);
	virtual	void Delete_at_first();
	virtual	void Delete_at_last();
	virtual	void Delete_from_position(T);
	virtual	void Delete_Node(T);
	virtual void Insert_at_Mid(T);
	void Display();
	bool IsEmpty(); 
	bool Search(T);
	int Sizeof();
	void Reverse();
	void sort();
	void Swap();
	void deleteDuplicates();
	T sum();
	~mydoubleLinkedList();
};
template <typename T>
Node<T>::Node() {
	this->value = 0;
	this->next = nullptr;
	this->previous = nullptr;
}
template <typename T>
Node<T>::Node(int v) {
	this->value = v;
	this->next = nullptr;
	this->previous = nullptr;
}
template <typename T>
mydoubleLinkedList<T>::mydoubleLinkedList() {
	this->Head = nullptr;
}
template <typename T>
void mydoubleLinkedList<T>::Insert_at_first(T v) {
	Node<T>* temp = new Node<T>(v);
	temp->next = this->Head;
	if(this->Head != nullptr)
	this->Head->previous = temp;
	this->Head = temp;
}
template <typename T>
void mydoubleLinkedList<T>::Insert_at_last(T v) {
	Node<T>* temp = new Node<T>(v);
	if (IsEmpty())
	{
		this->Insert_at_first(v);
		return;
	}
	Node<T>* temp2 = this->Head;
	while (temp2->next != nullptr)
	{
		temp2 = temp2->next;
	}
	temp2->next = temp;
	temp->previous = temp2;
}
template <typename T>
void mydoubleLinkedList<T>::Insert_at_position(T v, int index) {
	Node<T>* temp = new Node<T>(v);
	if (index == 0)
	{
		temp->previous = nullptr;
		temp->next = this->Head;
		this->Head = temp;
	}
	else
	{
		Node<T>* temp2 = this->Head;
		while (index > 1)
		{
			temp2 = temp2->next;
			index--;
		}
		temp->next = temp2->next;
		temp2->next = temp;
		temp2->previous = temp->next;
	}
}
template <typename T>
void mydoubleLinkedList<T>::Delete_at_first() {
	if (IsEmpty())
	{
		cout << "Linked List Is Empty" << endl;
	}
	else
	{
		Node<T>* temp = this->Head;
		this->Head = this->Head->next;
		this->Head->previous = nullptr;
		delete temp;
	}

}
template <typename T>
void mydoubleLinkedList<T>::Delete_at_last() {
	if (IsEmpty())
	{
		cout << "Linked List Is Empty" << endl;
	}
	else
	{
		Node<T>* temp = this->Head;
		Node<T>* temp2 = new Node<T>();
		while (temp->next != nullptr)
		{
			temp2 = temp;
			temp = temp->next;
		}
		delete temp;
		temp2->next = nullptr;
	}
}
template <typename T>
void mydoubleLinkedList<T>::Delete_from_position(T pos) {
	if (IsEmpty())
	{
		cout << "Linked List is Empty" << endl;
		return;
	}
	if (pos >= Sizeof())
	{
		cout << "Invalid Position" << endl;
		return;
	}
	if (pos == 0)
	{
		Node<T>* temp = this->Head;
		this->Head = this->Head->next;
		this->Head->previous = nullptr;
		delete temp;
		return;
	}
	Node<T>* temp =  this->Head->next;
	for (int i = 1; temp != nullptr; i++, temp = temp->next)
	{
		if (i == pos)
		{
			Node<T>* del = temp;
			temp = temp->previous;
			temp->next = temp->next->next;
			if (temp->next != nullptr)
				temp->next->previous = temp;
			delete del;
			break;
		}
	}


}
template <typename T>
void mydoubleLinkedList<T>::Delete_Node(T v) {
	Node<T>* temp = new Node<T>();
	temp = this->Head;
	bool found = false;
	int i = 0;
	while (temp!= nullptr)
	{
		if (temp->value == v)
		{
			found = true;
			break;
		}
		temp = temp->next;
		i++;
	}
	if (found)
	{
		Delete_from_position(i);

	}
	else
	{
		cout << "Value can not found" << endl;
	}
}
template <typename T>
bool mydoubleLinkedList<T>::IsEmpty() {
	if (this->Head == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
template <typename T>
int mydoubleLinkedList<T>::Sizeof() {
	int size = 0;
	if (IsEmpty())
	{
		return size;
	}
	Node<T>* temp = this->Head;
	while (temp != nullptr)
	{
		temp = temp->next;
		size++;
	}
	return size;
}
template <typename T>
void mydoubleLinkedList<T>::Display() {
	if (IsEmpty())
	{
		cout << "List is Empty" << endl;
	}
	else
	{
		Node<T>* temp = this->Head;
		cout << "Double Linked List:";
		cout << "NULL<-";
		while (temp != nullptr)
		{
			cout << temp->value << "->";
			temp = temp->next;
		}
		cout << "NULL" << endl;
	}
}
template <typename T>
bool mydoubleLinkedList<T>::Search(T i) {
	Node<T>* temp = this->Head;
	bool found = false;
	while (temp != nullptr)
	{
		if (temp->value == i)
		{
			found = true;
			break;
		}
		temp = temp->next;
	}
	if (found)
	{
		cout << "Enter Node is found" << endl;
		return true;
	}
	else
	{
		cout << "Node can not found" << endl;
		return false;
	}
}
template <typename T>
void mydoubleLinkedList<T>::Insert_at_Mid(T v) {
	int s = Sizeof() / 2;
	Insert_at_position(v, s);
}
template <typename T>
void mydoubleLinkedList<T>::Reverse(){
	if (IsEmpty())
	{
		cout << "List is Empty" << endl;
	}
	else
	{
		Node<T>* current = this->Head;
		Node<T>* temp = nullptr;
		Node<T>* next = nullptr;
		while (current != nullptr)
		{
			temp = current->previous;
			current->previous = current->next;
			current->next = temp;
			current = current->previous;
		}
		if (this->Head != nullptr)
		{
			this->Head = temp->previous;
		}
	}
}
template <typename T>
void mydoubleLinkedList<T>::sort() {
	Node<T>* temp1 = this->Head;
	Node<T>* temp2 = new Node<T>();
	Node<T>* temp3 = new Node<T>();
	while (temp1->next !=nullptr)
	{
		temp2 = temp1->next;
		while (temp2 != nullptr)
		{
			if (temp2->value < temp1->value)
			{
				temp3->value = temp1->value;
				temp1->value = temp2->value;
				temp2->value = temp3->value;
			}
			temp2 = temp2->next;
		}
		temp1 = temp1->next;
	}
}
template <typename T>
T mydoubleLinkedList<T>::sum() {
	T sum = 0;
	Node<T>* temp1 = this->Head;
	while (temp1 != nullptr)
	{
		sum = sum + temp1->value;
		temp1 = temp1->next;
	}
	return sum;
}

template <typename T>
void mydoubleLinkedList<T>::Swap() {
	Node<T>* temp1 = this->Head;
	Node<T>* temp2 = this->Head->next;
	Node<T>* temp3 = new Node<T>();
	Node<T>* temp4 = new Node<T>();
	while (temp2->next != nullptr)
	{ 
		temp2 = temp2->next;
	}
	temp3->value = temp2->value;
	temp4->value = temp1->value;
	temp1->value = temp3->value;
	temp2->value = temp4->value;
}
template <typename T>
void mydoubleLinkedList<T>::deleteDuplicates(){
	//Node<T>* temp = this->Head;
	//Node<T>* temp2 = new Node<T>();
	//bool found = false;
	//int i = 0;
	//while (temp != nullptr)
	//{
	//	temp2 = temp->next;
	//	while (temp2->next != nullptr)
	//	{
	//		if (temp->value == temp2->value)
	//		{
	//			found = true;
	//			i++;
	//			Delete_from_position(i);
	//			break;
	//			/*Delete_Node(temp->value);*/
	//		}
	//		temp2= temp2->next;
	//	}
	//	temp = temp->next;
	//}
	//if(!found)
	//{
	//	cout << "Value can not found" << endl;
	//}
}
template <typename T>
mydoubleLinkedList<T>::~mydoubleLinkedList() {
	Node<T>* temp = this->Head;
	if (this->Head != nullptr)
	{
		while (temp != nullptr)
		{
			this->Head = this->Head->next;
			delete temp;
			temp = this->Head;
		}
	}
}

