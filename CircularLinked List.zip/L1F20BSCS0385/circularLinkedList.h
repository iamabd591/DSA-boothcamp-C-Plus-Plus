#pragma once
#include<iostream>
using namespace std;
class Node {
public:
	int value;
	Node* next;
	Node();
	Node(int v);
};
class circularLinkedList
{
	Node* head;
	Node* tail;
public:
	circularLinkedList();
	void Insert_At_Start(int v);
	void Insert_At_Last(int v);
	void Delete_At_Start();
	void Delete_At_Last();
	void Sort();
	bool IsEmpty();
	int Sizeof();
	void PrintList();
	~circularLinkedList();

};

