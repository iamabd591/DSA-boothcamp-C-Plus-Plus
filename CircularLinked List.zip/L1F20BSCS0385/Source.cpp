#include"circularLinkedList.h"
int main()
{
	circularLinkedList cl;
	cl.Insert_At_Start(10);
	cl.Insert_At_Start(20);
	cl.Insert_At_Last(30);
	cl.Insert_At_Start(40);
	cl.Insert_At_Start(50);
	cl.Insert_At_Last(60);
	cl.PrintList();
	cout << "Size:" << cl.Sizeof() << endl;

	cl.Delete_At_Start();
	cout << "Delete From Start" << endl;
	cl.PrintList();


	cl.Delete_At_Last();
	cout << "Delete From Last" << endl;
	cl.PrintList();

	cl.Sort();
	cout << "Sorted ";
	cl.PrintList();


	return 0;
}