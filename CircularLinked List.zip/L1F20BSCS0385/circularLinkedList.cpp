#include "circularLinkedList.h"
Node::Node() {
	this->value = 0;
	this->next = 0;
}
Node::Node(int v) {
	this->value = v;
	this->next = nullptr;
}
circularLinkedList::circularLinkedList() {
	this->head = nullptr;
	this->tail = nullptr;
}
void circularLinkedList::Insert_At_Start(int v) {
	Node* temp = new Node(v);
	temp->next = this->head;
	if (IsEmpty())
	{
		this->tail = temp;
	}
	this->head = temp;
	this->tail->next = this->head;
}
void  circularLinkedList::Insert_At_Last(int v) {
	Node* temp = new Node(v);
	temp->next = this->head;
	if (this->tail==nullptr)
	{
		this->head = temp;
	}
	else
	{
		this->tail->next = temp;
		this->tail = temp;
	}
}
void circularLinkedList::Delete_At_Start() {
	if (IsEmpty())
	{
		cout << "List is empty" << endl;
	}
	else
	{ 
		Node* temp = this->head;
		this->head = this->head->next;
		this->tail->next = this->head;
		delete temp;
		temp = nullptr;
	}
}
void circularLinkedList::Delete_At_Last() {
	if (IsEmpty())
	{
		cout << "List is empty" << endl;
	}
	else
	{
		Node* temp = this->head;
		Node* temp2 = nullptr;
		while (temp->next != this->tail->next)
		{
			temp2 = temp;
			temp = temp->next;
		}	
		this->tail = temp2;
		this->tail->next = this->head;
		delete temp;
		temp = nullptr;
	}
}
void circularLinkedList::Sort() {
	Node* temp = this->head;
	Node* temp3 = new Node();
	Node* temp2 = new Node();
	while (temp->next != this->head)
	{
		temp2 = temp->next;
		while (temp2 != this->head)
		{
			if (temp2->value < temp->value)
			{
				temp3->value = temp->value;
				temp->value = temp2->value;
				temp2->value = temp3->value;
			}
			temp2 = temp2->next;
		}
		temp = temp->next;
	}
}

bool circularLinkedList::IsEmpty() {
	if (this->head == nullptr && this->tail==nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int circularLinkedList::Sizeof() {
	Node* temp = this->head;
	int count = 0;
	while (temp->next != this->head)
	{
		temp = temp->next;
		count++;
	}
	return ++count;

}
void circularLinkedList::PrintList() {
	if (IsEmpty()) {
		cout << "List is Empty" << endl;
	}
	else
	{
		Node* temp = this->head;
		cout << "Circular List:";
		while (temp->next != this->head)
		{
			cout << temp->value << "->";
			temp = temp->next;
		}
		cout << temp->value << endl;
	}
}
circularLinkedList::~circularLinkedList() {
	Node* temp = new Node();
	temp=this->head;
	while (temp->next != this->tail)
	{
		this->head= this->head->next;
		delete temp;
		temp = this->head;
	}
	delete temp;
}