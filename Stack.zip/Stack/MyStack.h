#pragma once
#include"Stack.h"
template <typename T>
class MyStack :public Stack <T>
{
private:
	T* arr;
	int size;
	int top;
	int count;
public:
	MyStack();
	MyStack(int);
	bool IsFull();
	bool IsEmpty();
	void Push(int) ;
	int Pop();
	int Size();
	int Peek();
	void PrintStack();
	void ReverseStack();
	~MyStack();

};
template <typename T>
MyStack<T>::MyStack() {
	this->arr = nullptr;
	this->size = 0;
	this->top = 0;
	this->count = 0;
}
template <typename T>
MyStack<T>::MyStack(int s) {
	this->size = s;
	this->top = -1;
	this->count = -1;
	this->arr = new int[this->size];
}
template <typename T>
bool MyStack<T>::IsFull() {
	if (this->top == this->size - 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
template <typename T>
bool MyStack<T>::IsEmpty() {
	if (this->top == -1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
template <typename T>
void MyStack<T>::Push(int value) {
	if (IsFull())
	{
		cout << "Stack is Full" << endl;
	}
	else
	{
		this->top++;
		this->arr[this->top] = value;
		this->count++;
	}
}
template <typename T>
int MyStack<T>::Pop() {
	int value = 0;
	if (IsEmpty())
	{
		cout << "Stack is Empty" << endl;
		return 0;
	}
	else
	{
		value = this->arr[this->top];
		this->top--;
		this->count--;
		return value;
	}
}
template <typename T>
int MyStack<T>::Size() {
	return this->count+1;
}
template <typename T>
int MyStack<T>::Peek() {
	return this->arr[this->top];
}

template <typename T>
void MyStack<T>::ReverseStack() {
	cout << "MyStack in reverse:";
	/*while(!IsEmpty())
	{
		cout << Pop() << " ";
	}*/
	for (int i = this->count + 1; i != 0; i--)
	{
		cout << Pop() << " ";
	}
}
template <typename T>
void MyStack<T>::PrintStack() {
	cout << "MyStack:";
	for (int i = 0; i < this->count+1; i++)
	{
		cout << this->arr[i] << " ";
	}
	cout << endl;
}
template <typename T>
MyStack<T>::~MyStack() {
	if (this->arr !=nullptr)
	{
		delete[] this->arr;
	}
}
