#pragma once
#include<iostream>
using namespace std;
template <typename T>
class Stack
{
public:
	virtual void Push(int) = 0;
	virtual int Pop() = 0;
	virtual int Size() = 0;
	virtual int Peek() = 0;
};

