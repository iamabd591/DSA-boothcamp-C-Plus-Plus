#include"MyStack.h"
int main()
{
	MyStack<int> obj(5);
	obj.Push(10);
	obj.Push(20);
	obj.Push(30);
	obj.Push(40);
	obj.Push(50);
	obj.PrintStack();
	obj.ReverseStack();
	return 0;
}