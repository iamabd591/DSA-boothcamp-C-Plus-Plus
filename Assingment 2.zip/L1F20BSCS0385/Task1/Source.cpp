#include"LinkedList.h"
int main()
{
	LinkedList List;
	int option = 0;
	int value = 0;
	int pos = 0;
	do {
		cout << "Press 1 For Insert At First" << endl;
		cout << "Press 2 For Insert At Last" << endl;
		cout << "Press 3 For Insert At Given Position" << endl;
		cout << "Press 4 For Delete From First" << endl;
		cout << "Press 5 For Eelete From Last" << endl;
		cout << "Press 6 For Delete From Given Position" << endl;
		cout << "Press 7 For Display LinkedList" << endl;
		cout << "Press 8 For Exixt" << endl;
		cin >> option;
		system("cls");
		switch (option) {
		case 1:
			cout << "Enter the Value:";
			cin >> value;
			List.Insert_At_First(value);
			system("cls");
			break;

		case 2:
			cout << "Enter the Value:";
			cin >> value;
			List.Insert_At_Last(value);
			system("cls");
			break;

		case 3:
			cout << "Enter the Value & Position Respectively:";
			cin >> value;
			cin >> pos;
			List.Insert_At_Pos(value,pos);
			system("cls");
			break;

		case 4:
			List.Delete_At_First();
			break;

		case  5:
			List.Delete_At_Last();
			break;

		case 6:
			cout<<"Ente the position :";
			cin >> pos;
			List.Delete_At_Pos(pos);
			system("cls");
			break;

		case 7:
			List.PrintLinkedList();
			break;

		case 8:
			exit(0);
			break;


		default:
			cout << "Invalid Input" << endl;
			break;
		}
	} while (true);
	return 0;
}