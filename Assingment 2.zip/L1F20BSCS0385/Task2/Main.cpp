#include"CircularLinkedList.h"
int main()
{
	CircularLinkedList Cl;
	Cl.Insert(1);
	Cl.Insert(2);
	Cl.Insert(3);
	Cl.Insert(4);
	Cl.Insert(5);
	Cl.PrintList();

	cout << "Size of List: " << Cl.Sizeof() << endl;
	if (Cl.isEmpty() == true)
	{
		cout<<"List is Empty" << endl;
	}
	else
	{
		cout << "List is Not Empty" << endl;
	}


	Cl.Delete(3);
	/*Cl.PrintList();*/
	return 0;
}