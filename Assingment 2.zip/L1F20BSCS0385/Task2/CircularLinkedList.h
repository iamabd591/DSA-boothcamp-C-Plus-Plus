#pragma once
#include<iostream>
using namespace std;
class Node {
public:
	int value;
	Node* next;
	Node();
	Node(int);
};
class CircularLinkedList
{
private:
	Node* head;
public:
	CircularLinkedList();
	bool isEmpty();
	int Sizeof();
	void Insert(int);
	void Delete(int);
	void PrintList();
	~CircularLinkedList();

};

