#include "CircularLinkedList.h"
Node::Node() {
	this->value = 0;
	this->next = nullptr;
}
Node::Node(int v) {
	this->value = v;
	this->next = nullptr;
}
CircularLinkedList::CircularLinkedList() {
	this->head = nullptr;
}
bool CircularLinkedList::isEmpty() {
	if (this->head == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int CircularLinkedList::Sizeof() {
	Node* temp = this->head;
	int count = 0;
	while (temp != nullptr)
	{
		temp = temp->next;
		count++;
	}
	return count;
}
void CircularLinkedList::Insert(int v) {
	Node* temp = new Node(v);
	if (isEmpty())
	{
		this->head = temp;
	}
	else
	{
		Node* temp2= this->head;
		while (temp2->next != nullptr)
		{
			temp2=temp2->next;
		}
		temp2->next = temp;
	}
}
void CircularLinkedList::Delete( int v) {
	Node* Tail = head;
	Node* temp = nullptr;
	if (isEmpty())
	{
		cout << "Circular Linked List is Empty" << endl;
	}
	else
	{
		if (this->head == nullptr)
		{
			delete head;
		}
		else
		{
			while (Tail->next != head)
			{
				Tail = Tail->next;
			}
			if (Tail->next->value == v)
			{
				temp = Tail->next;
				Tail->next=temp->next;
			}

		}
	}
}
void CircularLinkedList::PrintList() {
	if (this->head == nullptr)
	{
		cout << "List is Empty" << endl;
	}
	else
	{
		Node* temp = this->head;
		cout << "List is:";
		while (temp!= nullptr)
		{
			cout << temp->value << " ";
			temp = temp->next;
		}
		cout << endl;
	}
}
CircularLinkedList::~CircularLinkedList() {
	Node* temp = head;
	while (temp != nullptr)
	{
		head = head->next;
		delete temp;
		temp = head;
	}
}