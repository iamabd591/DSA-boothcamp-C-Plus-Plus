#include"Stack.h"
void Reverse(string& postfix);
int main()
{
	string prefix = "";
	prefix = "-*ab/c+dg";
	cout << "Prefix Expression:"<<prefix<<endl;

	cout << "Postfix Expression:"; 
	Reverse(prefix);
	return 0;
}
void Reverse(string& cstring) {
	string temp="";
	for (int i = cstring.size() - 1; i >= 0; i--)
	{
		temp += cstring[i];
	}
	cstring = temp;
	cout << cstring << endl;
}
