#include"Stack.h"
void Reverse(string& postfix);
int main()
{
	string postfix = "";
	postfix = "ab+cd-gh+/";
	cout<<"Postfix Exprssion:"<<postfix<<endl;

	cout << "PreFix Expression:"; 
	Reverse(postfix);
	return 0;
}

void Reverse(string& cstring) {
	string temp="";
	for (int i = cstring.size() - 1; i >= 0; i--)
	{
		temp += cstring[i];
	}
	cstring = temp;
	cout << cstring << endl;
}
