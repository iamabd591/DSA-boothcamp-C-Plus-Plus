#include"Stack.h"
int precedence(char a);
string infixTopostfixConvert(string infix);
int main()
{
	string infix = "", postfix = "";
	infix="(a+b)/(c*d-e+f)";
	cout<<"Infix Expression:"<<infix<<endl;
	postfix = infixTopostfixConvert(infix);
	cout << "PostFix Expression:" << postfix << endl;
	return 0;
}
int precedence(char a) {
	
		if (a == '+' || a == '-')
		{
			return 1;
		}
		else if (a == '/' || a == '*')
		{
			return 2;
		}
		else if (a == '^')
		{
			return 3;
		}
		else
		{
			return 0;
		}
}
string infixTopostfixConvert(string infix) {
	int i = 0;
	string postfix = "";
	Stack obj(20);
	while (infix[i] != '\0')
	{
		if (infix[i] >= '0' && infix[i] <= '9' || infix[i] >= 'a' && infix[i] <= 'z' || infix[i] >= 'A' && infix[i] <= 'Z')
		{
			postfix += infix[i];
			i++;
		}
		else if (infix[i] == '(')
		{
			obj.push(infix[i]);
			i++;
		}

		else if (infix[i] == ')')
		{
			while (obj.peek() != '(')
			{
				postfix += obj.pop();
			}
			obj.pop();
			i++;
		}
		else
		{
			while (!obj.isEmpty() && precedence(infix[i]) <= precedence(obj.peek()))
			{
				postfix += obj.pop();
			}
			obj.push(infix[i]);
			i++;
		}
	}
	while (!obj.isEmpty())
	{
		postfix += obj.pop();
	}
	return postfix;

}