#pragma once
#include<iostream>
#include<string>
//#include<stack>
using namespace std;
class Stack
{
protected:
	int* arr;
	int size;
	int top;
public:
	Stack();
	Stack(int);
	bool isFull();
	bool isEmpty();
	int push(int);
	int pop();
	int peek();
	int Size();
	~Stack();
};

