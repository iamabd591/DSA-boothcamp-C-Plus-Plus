#include "Stack.h"
Stack::Stack() {
	this->size = 0;
	this->top = 0;
	this->arr = nullptr;
}
Stack::Stack(int s) {
	this->size = s;
	this->arr = new int[this->size];
	this->top = -1;
}
bool Stack::isFull() {
	if (this->top >= this->size - 1) {
		return true;
	}
	else
	{
		return false;
	}
}
bool Stack::isEmpty() {
	if (this->top == -1) {
		return true;
	}
	else
	{
		return false;
	}
}
int Stack::push(int value) {
	if (this->isFull()==1)
	{
		cout << "Stack is Full" << endl;
		return false;
	}
	else
	{
		this->top++;
		this->arr[this->top] = value;
		return value;
	}
}
int Stack::pop() {
	int value = 0;
	if (this->isEmpty() == 1)
	{
		cout << "Stack is Empty" << endl;
		return false;
	}
	else
	{
		value = this->arr[this->top];
		this->top--;
		return value;
	}
}
int Stack::peek() {
	return this->arr[this->top];
}
int Stack::Size() {
	return this->size;
}

Stack::~Stack() {
	if (this->arr != nullptr)
	{
		delete[] this->arr;
	}
}