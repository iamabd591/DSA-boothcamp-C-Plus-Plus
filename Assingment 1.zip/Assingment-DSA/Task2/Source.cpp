#include"Stack.h"
int precedence(char a);
void Reverse(string& infix);
string infixTopostfixConvert(string cstring);
string infixToprefixConvert(string infix);
int main()
{
	string infix = "", prefix = "";
	infix = "(a+b)/(c-d)";
	cout << "Infix Expression:"<<infix<<endl;
	prefix = infixToprefixConvert(infix);
	cout << "PostFix Expression:" << prefix << endl;
	return 0;
}
int precedence(char a) {
	
		if (a == '+' || a == '-')
		{
			return 1;
		}
		else if (a == '/' || a == '*')
		{
			return 2;
		}
		else if (a == '^')
		{
			return 3;
		}
		else
		{
			return 0;
		}
}
string infixTopostfixConvert(string infix) {
	int i = 0;
	string postfix = "";
	Stack obj(20);
	while (infix[i] != '\0')
	{
		if (infix[i] >= '0' && infix[i] <= '9' || infix[i] >= 'a' && infix[i] <= 'z' || infix[i] >= 'A' && infix[i] <= 'Z')
		{
			postfix += infix[i];
			i++;
		}
		else if (infix[i] == '(')
		{
			obj.push(infix[i]);
			i++;
		}

		else if (infix[i] == ')')
		{
			while (obj.peek() != '(')
			{
				postfix += obj.pop();
			}
			obj.pop();
			i++;
		}
		else
		{
			while (!obj.isEmpty() && precedence(infix[i]) <= precedence(obj.peek()))
			{
				postfix += obj.pop();
			}
			obj.push(infix[i]);
			i++;
		}
	}
	while (!obj.isEmpty())
	{
		postfix += obj.pop();
	}
	return postfix;

}
void Reverse(string& cstring) {
	string temp="";
	for (int i = cstring.size() - 1; i >= 0; i--)
	{
		temp += cstring[i];
	}
	cstring = temp;
}
string infixToprefixConvert(string infix) {
	string prefix = "";
	Reverse(infix);
	for (int i = 0; i <=infix.size(); i++)
	{
		if (infix[i] == '(')
		{
			infix[i] = ')';
			i++;
		}
		else if (infix[i] == ')')
		{
			infix[i] = '(';
			i++;
		}
	}
	prefix = infixTopostfixConvert(infix);
	Reverse(prefix);
	return prefix;
}
