#include "LinkedList.h"
Node::Node() {
	this->value = 0;
	this->Next = nullptr;
}
Node::Node(int v) {
	this->value = v;
	this->Next = nullptr;
}
LinkedList::LinkedList(){
	this->Head = nullptr;
}
bool LinkedList::isEmpty() {
	if (this->Head == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int LinkedList::size() {
	int count = 0;
	Node* temp = this->Head;
	while (temp != nullptr)
	{
		temp = temp->Next;
		count++;
	}
	return count;
}
void LinkedList::Insert_At_First(int v) {
	Node* temp = new Node(v);
	temp->Next = this->Head;
	this->Head = temp;
}
void LinkedList::Insert_At_Last(int value) {
	Node* temp = new Node(value);
	if (isEmpty())
	{
		this->Head = temp;
	}
	else
	{
		Node* temp2 = this->Head;
		while (temp2->Next != nullptr)
		{
			temp2 = temp2->Next;
		}
		temp2->Next = temp;
	}
}
void LinkedList::Insert_At_Pos(int value, int pos) {
	Node* temp = new Node(value);
	if (pos == 0)
	{
		temp->Next = this->Head;
		this->Head = temp;
	}
	else
	{
		Node* temp2 = this->Head;
		while (pos > 1)
		{
			temp2 = temp2->Next;
			--pos;
		}
		temp->Next = temp2->Next;
		temp2->Next = temp;
	}
}
void LinkedList::Delete_At_First() {
	if (isEmpty())
	{
		cout << "Linked List is Empty" << endl;
	}
	else
	{
		Node* temp = this->Head;
		this->Head = Head->Next;
		delete temp;
	}
}
void LinkedList::Delete_At_Last() {
	if (isEmpty())
	{
		cout << "Linked List is Empty" << endl;
	}
	else if (Head->Next == nullptr)
	{
		delete Head;
	}
	else
	{
		Node* temp = this->Head;
		while (temp->Next!= nullptr)
		{
			temp = temp->Next;
		}
		delete temp;
	}
}
void LinkedList::Delete_At_Pos(int pos) {
	Node* temp = this->Head;
	if (isEmpty())
	{
		cout << "Linked List is Empty" << endl;
	}
	else if (pos == 0)
	{
		Node* temp = this->Head;
		this->Head = Head->Next;
		delete temp;
	}
	else
	{
		Node* temp2 = this->Head;
		while (pos > 0)
		{
			--pos;
		    temp = temp->Next;
		}
		temp2->Next = temp->Next;
		delete temp;
	}
}
void LinkedList::PrintLinkedList() {
	if (isEmpty())
	{
		cout << "Linked List is Empty" << endl;
	}
	else
	{
		Node* temp = this->Head;
		cout << "Linked List:";
		while (temp != nullptr)
		{
			cout << temp->value << " ";
			temp = temp->Next;
		}
		cout << endl;
	}
}
LinkedList::~LinkedList() {
	Node* temp = Head;
	while (temp != nullptr)
	{
		Head = Head->Next;
		delete temp;
		temp = Head;
	}
}