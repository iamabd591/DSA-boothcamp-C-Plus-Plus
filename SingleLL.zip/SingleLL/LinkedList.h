#pragma once
#include<iostream>
using namespace std;
class Node {
public:
	int value;
	Node* Next;
	Node();
	Node(int);

};
class LinkedList
{
private:
	Node* Head;
public:
	LinkedList();
	bool isEmpty();
	int size();
	void Insert_At_First(int);
	void Insert_At_Last(int);
	void Insert_At_Pos(int, int);
	void Delete_At_First();
	void Delete_At_Last();
	void Delete_At_Pos(int);
	void PrintLinkedList();
	~LinkedList();
};

