#pragma once
#include"BST.h"
template <typename T>
class MyBST :public BST <T>
{
public:
	MyBST() {};
	~MyBST() {};
	MyBST(const MyBST& Obj);
	Node<T>* getRoot();
	T Count_Occurrence(T data);
	bool isEmpty();
	bool isBST();
	bool Search(T data);
	bool CheckIsCOmplete();
	void insertNode(T data);
	void deleteNode(T data);
	void inOrder();
	void preOrder();
	void postOrder();
	void LeveLOrder();
	void FindMini();
	void FindMax();
	void Find2Max();
	void PrintleafNode();
	void Sumofleaf();
	void CountLeaf();
	void CalculateSumofTree();
	void Check(T data);
	void CountNodes();
	void PrintHeight();
	void getlevelofnode(T data);
	void PrintPath(T data);
	void PrintArray(int Arr[], int lenght);
	void PrintAllPath();

private:
	Node<T>* insertNode(Node<T>* root, T data);
	Node<T>* deleteNOde(Node<T>* root, T data);
	T FindMini(Node<T>* root);
	T FindMax(Node<T>* root);
	T Find2Max(Node<T>* root);
	T CountLeaf(Node<T>* root);
	T CalculateSumofTree(Node<T>* root);
	int Sumofleaf(Node<T>* root);
	int CountNodes(Node<T>* root);
	bool isBST(Node<T>* root);
	bool Search(Node<T>* root, T data);
	bool CheckIsCOmplete(Node<T>* root, int index, int nofonodes);
	void Check(Node<T>* root, T data);
	void inOrder(Node<T>* root);
	void preOrder(Node<T>* root);
	void postOrder(Node<T>* root);
	void LeveLOrder(Node<T>* root);
	int  PrintHeight(Node<T>* root);
	int getlevelofnode(Node<T>* root, T data, int level);
	void copyTree(Node<T>* root);
	void PrintleafNode(Node<T>* root);
	void PrintPath(Node<T>* root, T data);
	void PrintAllPath(Node<T>* root, int Arr[], int lenght);
};

template<typename T>
inline MyBST<T>::MyBST(const MyBST& Obj)
{
	this->copyTree(Obj.getRoot());
}

template<typename T>
inline void MyBST<T>::insertNode(T data) {
	this->Root = this->insertNode(this->Root, data);
}

template<typename T>
inline void MyBST<T>::inOrder() {
	cout << "Inorder: ";
	this->inOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBST<T>::preOrder() {
	cout << "Preorder: ";
	this->preOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBST<T>::postOrder() {
	cout << "Postorder: ";
	this->postOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBST<T>::LeveLOrder() {
	cout << "Level Order:";
	this->LeveLOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBST<T>::FindMini()
{
	cout << "MiniMun Value in Tree is:";
	this->FindMini(this->Root);
	cout << endl;
}
template<typename T>
inline void MyBST<T>::FindMax()
{
	cout << "Maximum Value in Tree is:";
	this->FindMax(this->Root);
	cout << endl;
}
template<typename T>
inline void MyBST<T>::Find2Max()
{
	cout << "Second Maximum Value in Tree is:";
	this->Find2Max(this->Root);
	cout << endl;
}
template<typename T>
inline void MyBST<T>::PrintleafNode()
{
	cout << "Leaf Nodes:";
	this->PrintleafNode(this->Root);
	cout << endl;
}
template<typename T>
inline void MyBST<T>::Sumofleaf()
{
	cout << "Sum of Leaf:" << this->Sumofleaf(this->Root) << endl;
}
template<typename T>
inline void MyBST<T>::CountLeaf()
{
	cout << "No of Leafs in Tree:" << this->CountLeaf(this->Root) << endl;
}
template<typename T>
inline void MyBST<T>::CalculateSumofTree()
{
	cout << "Sum of Tree:" << this->CalculateSumofTree(this->Root);
}
template<typename T>
inline void MyBST<T>::Check(T data)
{
	this->Check(this->Root, data);
}
template<typename T>
inline void MyBST<T>::CountNodes()
{
	cout << "Total No of Nodes:" << this->CountNodes(this->Root) << endl;
}
template<typename T>
inline void MyBST<T>::PrintHeight()
{
	cout << "Height of a Tree:" << this->PrintHeight(this->Root) << endl;
}
template<typename T>
inline void MyBST<T>::getlevelofnode(T data)
{
	if (!this->getlevelofnode(this->Root, data, 1))
	{
		cout << "Node is Not Found At Any Level" << endl;
	}
	else
	{
		cout << "Node " << data << " Foud At Level " << this->getlevelofnode(this->Root, data, 1) << endl;
	}

}
template<typename T>
inline void MyBST<T>::PrintPath(T data)
{
	this->PrintPath(this->Root, data);
}
template<typename T>
inline void MyBST<T>::PrintArray(int Arr[], int lenght)
{
	cout << "All Paths From Root:";
	for (int i = 0; i < lenght; i++)
	{
		cout << Arr[i] << " ";
	}
	cout << endl;
}
template<typename T>
inline void MyBST<T>::PrintAllPath()
{
	int Array[1000];
	this->PrintAllPath(this->Root, Array, 0);
}
template<typename T>
inline T MyBST<T>::Count_Occurrence(T data)
{
	T count = 0;
	if (this->Root == nullptr)
	{
		return count;
	}
	if (this->Root->data == data)
	{
		return ++count;
	}
	if (this->Root->data < data)
	{
		if (this->Search(this->Root->Right, data))
			return ++count;
	}
	else if (this->Search(this->Root->Left, data))
	{
		return ++count;
	}
	return count;
}

template<typename T>
inline bool MyBST<T>::isEmpty()
{
	if (this->Root == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
template<typename T>
inline T MyBST<T>::FindMini(Node<T>* root)
{
	if (root == nullptr)
	{
		return T(0);
	}
	Node<T>* temp = root;
	while (temp->Left != nullptr)
	{
		temp = temp->Left;
	}
	cout << temp->data;
	return temp->data;
}

template<typename T>
inline T MyBST<T>::FindMax(Node<T>* root)
{
	if (root == nullptr)
	{
		return T(0);
	}
	else
	{
		Node<T>* temp = root;
		while (temp->Right != nullptr)
		{
			temp = temp->Right;
		}
		cout << temp->data;
		return temp->data;
	}
}

template<typename T>
inline T MyBST<T>::Find2Max(Node<T>* root)
{
	if (root == nullptr)
	{
		return T(0);
	}
	else
	{
		Node<T>* temp = root;
		Node<T>* temp2 = new Node<T>();
		while (temp->Right != nullptr)
		{
			temp2 = temp;
			temp = temp->Right;
		}
		cout << temp2->data;
		return temp2->data;
	}
}

template<typename T>
inline T MyBST<T>::CountLeaf(Node<T>* root)
{
	T count = 0;
	if (root == nullptr)
	{
		return T(0);
	}
	if (!root->Left && !root->Right)
	{
		return T(1);
	}
	else
	{
		count = this->CountLeaf(root->Left) + this->CountLeaf(root->Right);
		return count;
	}
}

template<typename T>
inline int MyBST<T>::Sumofleaf(Node<T>* root)
{
	int sum = 0;
	if (root == nullptr) {
		return 0;
	}
	else if (!root->Left && !root->Right) {
		return sum += root->data;
	}
	else {
		return sum += this->Sumofleaf(root->Left) + this->Sumofleaf(root->Right);
	}
}

template<typename T>
inline int MyBST<T>::CountNodes(Node<T>* root)
{
	if (root == nullptr) {
		return 0;
	}
	else {
		return 1 + this->CountNodes(root->Left) + this->CountNodes(root->Right);
	}
}

template<typename T>
inline T MyBST<T>::CalculateSumofTree(Node<T>* root)
{
	T sum = 0;
	if (root == nullptr) {
		return T(0);
	}
	else if (root->Left == nullptr && root->Right == nullptr) {
		sum = root->data;
		return sum;
	}
	else
	{
		queue <Node<T>*> Q;
		Q.push(root);
		while (!Q.empty())
		{
			Node<T>* temp = Q.front();
			Q.pop();
			sum = sum + temp->data;
			if (temp->Left)
			{
				Q.push(temp->Left);
			}
			if (temp->Right)
			{
				Q.push(temp->Right);
			}
		}
		return sum;

	}
}

template<typename T>
inline bool MyBST<T>::Search(T data) {
	return this->Search(this->Root, data);
}

template<typename T>
inline bool MyBST<T>::CheckIsCOmplete()
{
	int nofonodes = this->CountNodes(this->Root);
	int index = 0;
	if (this->CheckIsCOmplete(this->Root, index, nofonodes)) {
		cout << "Its A CompleteTree" << endl;
		return true;
	}
	else
	{
		cout << "Its Not A CompleteTree" << endl;
		return false;
	}
}

template<typename T>
inline void MyBST<T>::deleteNode(T data) {
	this->Root = this->deleteNOde(this->Root, data);
}

template<typename T>
inline bool MyBST<T>::isBST()
{
	return this->isBST(this->Root);
}


template<typename T>
inline Node<T>* MyBST<T>::insertNode(Node<T>* root, T data) {
	if (root == nullptr) {
		return new Node<T>(data);
	}
	if (root->data < data) {
		root->Right = this->insertNode(root->Right, data);
	}
	else {
		root->Left = this->insertNode(root->Left, data);
	}
	return root;
}

template<typename T>
inline bool MyBST<T>::Search(Node<T>* root, T data) {
	if (root == nullptr) {
		return false;
	}
	if (root->data == data) {
		return true;
	}
	if (root->data < data) {
		return Search(root->Right, data);
	}
	else {
		return Search(root->Left, data);
	}
}
template<typename T>
inline bool MyBST<T>::CheckIsCOmplete(Node<T>* root, int index, int nofonodes)
{
	if (root == nullptr)
	{
		return true;
	}
	if (index >= nofonodes)
	{
		return false;
	}
	else {
		return (this->CheckIsCOmplete(root->Left, 2 * index + 1, nofonodes) && this->CheckIsCOmplete(root->Right, 2 * index + 2, nofonodes));
	}
}
template<typename T>
inline Node<T>* MyBST<T>::deleteNOde(Node<T>* root, T data) {
	if (root == nullptr) {
		return root;
	}
	if (root->data > data) {
		root->Left = this->deleteNOde(root->Left, data);
	}
	else if (root->data < data) {
		root->Right = this->deleteNOde(root->Right, data);
	}
	else
	{
		if (root->Left == nullptr && root->Right == nullptr)
		{
			delete root;
			return nullptr;
		}
		else if (root->Right == nullptr)
		{
			Node<T>* temp = root->Left;
			delete root;
			return temp;
		}
		else if (root->Left == nullptr)
		{
			Node<T>* temp = root->Right;
			delete root;
			return temp;
		}
		else {
			Node<T>* temp = root->Right;
			while (temp->Left != nullptr) {
				temp = temp->Left;
			}
			root->data = temp->data;
			root->Right = this->deleteNOde(root->Right, temp->data);
		}
	}
	return root;
}
template<typename T>
inline void MyBST<T>::PrintleafNode(Node<T>* root)
{
	if (root == nullptr)
	{
		return;
	}
	if (!root->Left && !root->Right)
	{
		cout << root->data << " ";
	}
	else
	{
		this->PrintleafNode(root->Left);
		this->PrintleafNode(root->Right);
	}
}
template<typename T>
inline void MyBST<T>::PrintPath(Node<T>* root, T data)
{
	if (root == nullptr)
	{
		return;
	}
	else if (root->data == data)
	{
		cout << root->data << " ";
	}
	else if (root->data > data)
	{
		cout << "Path:";
		cout << root->data << " ";
		Node<T>* temp = root;
		while (temp->Left->data != data)
		{
			cout << root->Left->data << " ";
			break;
		}
		cout << data << " " << endl;
	}
	else
	{
		cout << "Path:";
		cout << root->data << " ";
		Node<T>* temp = root;
		while (temp->Right->data != data)
		{
			cout << root->Right->data << " ";
			break;
		}
		cout << data << " " << endl;
	}
}
template<typename T>
inline void MyBST<T>::PrintAllPath(Node<T>* root, int Arr[],int lenght)
{
	if (root == nullptr) {
		return;
	}
	Arr[lenght] = root->data;
	lenght++;
	if (!root->Left && !root->Right)
	{
		this->PrintArray(Arr, lenght);
	}
	else
	{
		this->PrintAllPath(root->Left, Arr, lenght);
		this->PrintAllPath(root->Right, Arr, lenght);
	}
}
template<typename T>
inline void MyBST<T>::inOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		this->inOrder(root->Left);
		cout << root->data << " ";
		this->inOrder(root->Right);
	}
}
template<typename T>
inline void MyBST<T>::preOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		cout << root->data << " ";
		this->preOrder(root->Left);
		this->preOrder(root->Right);
	}
}
template<typename T>
inline void MyBST<T>::postOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		this->postOrder(root->Left);
		this->postOrder(root->Right);
		cout << root->data << " ";
	}
}

template<typename T>
inline void MyBST<T>::LeveLOrder(Node<T>* root)
{
	if (root == nullptr)
	{
		return;
	}
	else
	{
		queue <Node<T>*> Q;
		Q.push(root);
		while (!Q.empty())
		{
			Node<T>* Current = Q.front();
			cout << Current->data << " ";
			if (Current->Left != nullptr)
			{
				Q.push(Current->Left);
			}
			if (Current->Right != nullptr)
			{
				Q.push(Current->Right);
			}
			Q.pop();
		}
	}
}

template<typename T>
inline int MyBST<T>::PrintHeight(Node<T>* root)
{
	if (root == nullptr)
	{
		return 0;
	}
	int lheight = PrintHeight(root->Left);
	int rheight = PrintHeight(root->Right);
	if (lheight > rheight)
	{
		return ++lheight;
	}
	else
	{
		return ++rheight;
	}
}

template<typename T>
inline int MyBST<T>::getlevelofnode(Node<T>* root, T data, int level)
{
	if (root == nullptr)
	{
		return 0;
	}
	else if (root->data == data)
	{
		return level;
	}
	else
	{
		int CalculateLevel = 0;
		CalculateLevel = getlevelofnode(root->Left, data, level + 1);
		if (CalculateLevel == 0)
		{
			int CalculateLevel2 = getlevelofnode(root->Right, data, level + 1);
			return CalculateLevel2;
		}
		else
		{
			return CalculateLevel;
		}
	}
}

template<typename T>
inline void MyBST<T>::copyTree(Node<T>* root)
{
	if (root == nullptr)
		return;
	queue<Node<T>*> q;
	while (1)
	{
		while (root != nullptr)
		{
			q.push(root);
			root = root->Left;
		}
		if (q.empty)
			return;
		root = q.front();
		q.pop();
		this->insertNode(root->data);
		root = root->Right;
	}
}

template<typename T>
inline Node<T>* MyBST<T>::getRoot()
{
	return this->Root;
}

template<typename T>
inline bool MyBST<T>::isBST(Node<T>* root)
{
	if (root == nullptr) {
		return false;
	}
	if (!root->Left && root->Right)
	{
		return isBST(root->Right);
	}
	if (!root->Right && root->Left)
	{
		return isBST(root->Left);
	}
	if (root->Left == nullptr && root->Right == nullptr)
	{
		return true;
	}
	if (root->Left->data > root->Right->data)
	{
		return false;
	}
	else
	{
		return isBST(root->Left) && isBST(root->Right);
	}
}

template<typename T>
inline void MyBST<T>::Check(Node<T>* root, T data)
{
	if (root == nullptr) {
		return;
	}
	else if (root->data == data) {
		cout << "Its A Parent" << endl;
	}
	else if (root->Left)
	{
		Node<T>* temp = root;
		Node<T>* temp2 = new Node<T>();
		while (temp->Left != nullptr)
		{
			temp2 = temp;
			temp = temp->Left;
			if (temp->Left->data == data)
			{
				cout << "Its A Leaf" << endl;
				break;
			}
			if (temp2->Left->data == data)
			{
				cout << "Its A Left Child" << endl;
				break;
			}
		}
	}
	else if (root->Right)
	{
		Node<T>* temp = root;
		Node<T>* temp2 = new Node<T>();
		while (temp->Right != nullptr)
		{
			temp2 = temp;
			temp = temp->Right;
			if (temp->Right->data == data)
			{
				cout << "Its A Leaf" << endl;
				break;
			}
			if (temp2->Right->data == data)
			{
				cout << "Its A Right Child" << endl;
				break;
			}
		}
	}
	else
	{
		cout << "Node can not exixt" << endl;
	}
}
