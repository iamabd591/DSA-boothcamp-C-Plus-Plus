#pragma once
#include<iostream>
#include<queue>
#include<stack>
using namespace std;
template <typename T>
class Node
{
public:
	T data;
	Node<T>* Left;
	Node<T>* Right;
	Node();
	Node(T);
};
template <typename T>
Node<T>::Node() {
	this->data = 0;
	this->Left = nullptr;
	this->Right = nullptr;
}
template <typename T>
Node<T>::Node(T d) {
	this->data = d;
	this->Left = nullptr;
	this->Right = nullptr;
}
template <typename T>
class BST
{
protected:
	Node<T>* Root;
	void clearTree(Node<T>* root);
public:
	BST();
	virtual Node<T>* insertNode(Node<T>* root, T data) = 0;
	virtual Node<T>* deleteNOde(Node<T>* root, T data) = 0;
	virtual T Count_Occurrence(T data) = 0;
	virtual bool Search(T data) = 0;
	virtual void inOrder(Node<T>* root) = 0;
	virtual void preOrder(Node<T>* root) = 0;
	virtual void postOrder(Node<T>* root) = 0;
	virtual void LeveLOrder(Node<T>* root) = 0;
	~BST();
};
template<typename T>
inline BST<T>::BST()
{
	this->Root = nullptr;
}

template<typename T>
inline void BST<T>::clearTree(Node<T>* root)
{
	if (root == nullptr)
	{
		return;
	}
	else {
		this->clearTree(root->Left);
		this->clearTree(root->Right);
		delete root;
	}
}
template<typename T>
inline BST<T>::~BST()
{
	if (this->Root != nullptr) {
		this->clearTree(this->Root);
	}
}
