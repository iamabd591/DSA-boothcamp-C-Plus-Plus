#include "MyBST.h"
int main()
{
	MyBST<int> Tree;

	Tree.insertNode(25);
	Tree.insertNode(19);
	Tree.insertNode(29);
	Tree.insertNode(17);
	Tree.insertNode(20);
	Tree.insertNode(27);
	Tree.insertNode(55);
	Tree.inOrder();
	Tree.postOrder();
	Tree.preOrder();
	Tree.LeveLOrder();
	/*<!-----------------------!>*/
	Tree.Sumofleaf();
	Tree.Check(17);
	Tree.CountNodes();
	Tree.CheckIsCOmplete();
	Tree.PrintHeight();
	Tree.getlevelofnode(26);
	Tree.PrintPath(55);
	Tree.PrintAllPath();
	/*int option = 0;
	int a = 0;
	do
	{
		cout << "\t\t\t\t\t-----------------------------------" << endl;
		cout << "\t\t\t\t\t|        BINARY SEARCH TREE       |" << endl;
		cout << "\t\t\t\t\t|---------------------------------|" << endl;
		cout << "\t\t\t\t\t|Press 1 for Insert A Node        |" << endl;
		cout << "\t\t\t\t\t|Press 2 for Delete A Node        |" << endl;
		cout << "\t\t\t\t\t|Press 3 for Search A Node        |" << endl;
		cout << "\t\t\t\t\t|Press 4 for Inorder Trvasal      |" << endl;
		cout << "\t\t\t\t\t|Press 5 for Preorder Trvasal     |" << endl;
		cout << "\t\t\t\t\t|Press 6 for Prostorder Trvasal   |" << endl;
		cout << "\t\t\t\t\t|Press 7 for Level Trvasal        |"<< endl;
		cout << "\t\t\t\t\t|Press 8 for Check is Empty or Not|" << endl;
		cout << "\t\t\t\t\t|Press 9 for Count Occurrence     |" << endl;
		cout << "\t\t\t\t\t|Press 10 for Check Tree is BST   |" << endl;
		cout << "\t\t\t\t\t|Press 11 for Minimum Value       |" << endl;
		cout << "\t\t\t\t\t|Press 12 for Maximum Value       |" << endl;
		cout << "\t\t\t\t\t|Press 13 for 2 Maximum Value     |" << endl;
		cout << "\t\t\t\t\t|Press 14 for Print Leaf Node     |" << endl;
		cout << "\t\t\t\t\t|Press 15 for Sum of Tree         |" << endl;
		cout << "\t\t\t\t\t|Press 16 for Print Leaf          |" << endl;
		cout << "\t\t\t\t\t|Press 17 for Exixt               |" << endl;
		cout << "\t\t\t\t\t------------------------------------" << endl;
		cin >> option;
		switch (option)
		{
		case 1:
			cout << "\t\t\t\t\tEnter the Node Value:";
			cin >> a;
			Tree.insertNode(a);
			system("cls");
			Tree.inOrder();
			Tree.preOrder();
			Tree.postOrder();
			Tree.LeveLOrder();
			cout << endl;
			break;

		case 2:
			cout << "Enter the Node Value:";
			cin >> a;
			Tree.deleteNode(a);
			system("cls");
			Tree.inOrder();
			Tree.preOrder();
			Tree.postOrder();
			Tree.LeveLOrder();
			cout << endl;
			break;

		case 3:
			cout << "Enter the Node Value:";
			cin >> a;
			Tree.Search(a);
			system("cls");
			if (Tree.Search(a)) {
				cout << "Found It" << endl;
			}
			else {
				cout << "Not Found" << endl;
			}
			break;

		case 4:
			system("cls");
			Tree.inOrder();
			break;

		case 5:
			system("cls");
			Tree.preOrder();
			break;

		case 6:
			system("cls");
			Tree.postOrder();
			break;

		case 7:
			system("cls");
			Tree.LeveLOrder();
			break;

		case 8:
			system("cls");
			if (Tree.isEmpty())
			{
				cout << "Tree is Empty" << endl;
			}
			else
			{
				cout << "Tree is Not Empty" << endl;
			}
			break;

		case 9:
			cout << "Enter the Node Value:";
			cin >> a;
			cout << "Count:" << Tree.Count_Occurrence(a) << endl;
			break;

		case 10:
			if (Tree.isBST())
			{
				cout << "Its a BST Tree" << endl;
			}
			else
			{
				cout<<"Its is Not a BST Tree" << endl;
			}
			break;

		case 11:
			system("cls");
			Tree.FindMini();
			break;

		case 12:
			system("cls");
			Tree.FindMax();
			break;

		case 13:
			system("cls");
			Tree.Find2Max();
			break;
		

		case 14:
			system("cls");
			Tree.PrintleafNode();
			break;

		case 15:
			system("cls");
			Tree.CalculateSumofTree();
			break;

		case 16:
			system("cls");
			Tree.CountLeaf();
			break;

		case 17:
			exit(0);
			break;

		default:
			cout << "Invalid Value" << endl;
			break;
		}

	} while (true);*/
	return 0;
}