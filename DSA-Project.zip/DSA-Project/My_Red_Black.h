#include"Red_Black.h"
#pragma once
template <typename T>
class My_Red_Black : public  Red_Black <T>
{
private:
	Node<T>* InsertNode(Node<T>* root, T Data);
	Node<T>* DeleteNode(Node<T>* root, T Data);
	Node<T>* SearchNode(Node<T>* root, T Data);
	Node<T>* grandParent(Node<T>* node);
	Node<T>* uncle(Node<T>* node);
	Node<T>* sibling(Node<T>* node);
	void InsertFix(Node<T>* node);
	void DeleteFix(Node<T>* node);
	void InOrder(Node<T>* root, T a);
	void PreOrder(Node<T>* root, T a);
	void PostOrder(Node<T>* root, T a);
	void DisplayColor(Node<T>* root);
	void RigthRotate(Node<T>* ptr);
	void LeftRotatae(Node<T>* ptr);

public:
	My_Red_Black() {};
	void Insert(T Data);
	void DispalyParent(T Data);
	void DeleteNode(T Data);
	void InOrder(int);
	void PreOrder(int);
	void PostOrder(int);
	void DisplayColor();
	bool SearchNode(T Data);
	~My_Red_Black() {};
};



//***********************************Public Function*********************************************
template<typename T>
inline void My_Red_Black<T>::InOrder(int a)
{
	cout << "\t\t\t\t\t------------------------------------------------" << endl;
	cout << "\t\t\t\t\t|                   IN-ORDER                   |" << endl;
	if (a == 1)
	{

		cout << "\t\t\t\t\t|                     LNR                      |" << endl;
		cout << "\t\t\t\t\t-----------------------------------------------" << endl;
		cout << "\t\t\t\t\t|"; this->InOrder(this->Root, a); cout << "|";
		cout << endl;
		cout << "\t\t\t\t\t-----------------------------------------------" << endl;
	}
	else if (a == 2)
	{

		cout << "\t\t\t\t\t|                     RNL                      |" << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
		cout << "\t\t\t\t\t|"; this->InOrder(this->Root, a); cout << "|";
		cout << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
	}
}
template<typename T>
inline void My_Red_Black<T>::PreOrder(int a)
{
	cout << "\t\t\t\t\t------------------------------------------------" << endl;
	cout << "\t\t\t\t\t|                   Pre-ORDER                  |" << endl;
	if (a == 1)
	{

		cout << "\t\t\t\t\t|                     NLR                      |" << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
		cout << "\t\t\t\t\t|"; this->PreOrder(this->Root, a); cout << "|";
		cout << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
	}
	else if (a == 2)
	{

		cout << "\t\t\t\t\t|                     NRL                      |" << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
		cout << "\t\t\t\t\t|"; this->PreOrder(this->Root, a); cout << "|";
		cout << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
	}
}
template<typename T>
inline void My_Red_Black<T>::PostOrder(int a)
{
	cout << "\t\t\t\t\t------------------------------------------------" << endl;
	cout << "\t\t\t\t\t|                   POST-ORDER                 |" << endl;
	if (a == 1)
	{

		cout << "\t\t\t\t\t|                      LRN                     |" << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
		cout << "\t\t\t\t\t|"; this->PostOrder(this->Root, a); cout << "|";
		cout << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
	}
	else if (a == 2)
	{

		cout << "\t\t\t\t\t|                       RLN                    |" << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
		cout << "\t\t\t\t\t|"; this->PostOrder(this->Root, a); cout << "|";
		cout << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
	}
}
template<typename T>
inline bool My_Red_Black<T>::SearchNode(T Data)
{
	if (this->SearchNode(this->Root, Data))
	{
		return true;
	}
	else {
		return false;
	}
}
template<typename T>
inline void My_Red_Black<T>::DisplayColor()
{
	cout << "-----------------" << endl;
	cout << "|      Color     |" << endl;
	cout << "-----------------" << endl;
	this->DisplayColor(this->Root);
	cout << endl;
}






//***********************************Private Function********************************************
template<typename T>
inline Node<T>* My_Red_Black<T>::InsertNode(Node<T>* root, T Data)
{
	if (root == nullptr)
	{
		Node<T>* temp = new Node<T>(Data);
		root = temp;
		return root;
	}
	if (root->Data < Data)
	{
		root->Right = this->InsertNode(root->Right, Data);
		root->Right->Color = -1;
		root->Right->Parent = root;
	}
	else if (root->Data > Data)
	{
		root->Left = this->InsertNode(root->Left, Data);
		root->Left->Color = -1;
		root->Left->Parent = root;
	}
	return root;
}

template<typename T>
inline Node<T>* My_Red_Black<T>::DeleteNode(Node<T>* root, T Data)
{
	if (root == nullptr) 
	{
		return root;
	}
	if (root->Data > Data) 
	{
		root->Left = this->DeleteNode(root->Left, Data);
	}
	else if (root->Data < Data) 
	{
		root->Right = this->DeleteNode(root->Right, Data);
	}
	else
	{
		if (root->Left == nullptr && root->Right == nullptr)
		{
			delete root;
			return nullptr;
		}
		else if (root->Right == nullptr)
		{
			Node<T>* temp = root->Left;
			delete root;
			return temp;
		}
		else if (root->Left == nullptr)
		{
			Node<T>* temp = root->Right;
			delete root;
			return temp;
		}
		else 
		{
			Node<T>* temp = root->Right;
			while (temp->Left != nullptr) 
			{
				temp = temp->Left;
			}
			root->Data = temp->Data;
			root->Right = this->DeleteNode(root->Right, temp->Data);
		}
	}
	return root;
}

template<typename T>
inline void My_Red_Black<T>::InsertFix(Node<T>* node)
{
	Node<T>* uncle = nullptr; 
	while (node->Parent && node->Parent->Color == -1) {
		if (this->grandParent(node)->Left && this->grandParent(node)->Left == node->Parent)
		{
			uncle = this->grandParent(node)->Right;
			if (uncle && uncle->Color == -1) 
			{

				uncle->Color = 1;
				node->Parent->Color = 1;
				node->Parent->Parent->Color = -1;
				node = node->Parent->Parent;
			}
			else 
			{

				if (node == node->Parent->Right) 
				{
					node = node->Parent;
					this->LeftRotatae(node);
				}
				node->Parent->Color = 1;
				node->Parent->Parent->Color = -1;
				this->RigthRotate(node->Parent->Parent);
			}
		}
		else {
			uncle = this->grandParent(node)->Left;
			if (uncle && uncle->Color == -1)
			{
				uncle->Color = 1;
				node->Parent->Color = 1;
				node->Parent->Parent->Color = -1;
				node = node->Parent->Parent;
			}
			else
			{
				if (node == node->Parent->Left)
				{
					node = node->Parent;
					this->RigthRotate(node);
				}
				node->Parent->Color = 1;
				node->Parent->Parent->Color = -1;
				this->LeftRotatae(node->Parent->Parent);
			}
		}
	}
	this->Root->Color = 1;
}

template<typename T>
inline void My_Red_Black<T>::DeleteFix(Node<T>* node)
{
	Node<T>* sibling = nullptr;
	while (node != this->Root && node->Color == 1)
	{
		if (node == node->Parent->Left)
		{
			sibling = node->Parent->Right;
			if (sibling && sibling->Color == -1)
			{
				sibling->Color = 1;
				node->Parent->Color = -1;
				this->LeftRotatae(node->Parent);
				sibling = node->Parent->Right;
			}
			if ((sibling->Left && sibling->Right) && (sibling->Left->Color == 1 && sibling->Right->Color == 1)) 
			{
				sibling->Color = -1;
				node = node->Parent;
			}
			else
			{
				if (sibling->Right && sibling->Right->Color == 1)
				{
					sibling->Left->Color = 1;
					sibling->Color = -1;
					this->RigthRotate(sibling);
					sibling = node->Parent->Right;
				}
				sibling->Color = node->Parent->Color;
				node->Parent->Color = 1;
				if (sibling->Right)
				{
				sibling->Right->Color = 1;
			    }
				this->LeftRotatae(node->Parent);
				node = this->Root;
			}
		}
		else
		{
			sibling = node->Parent->Left;
			if (sibling && sibling->Color == -1)
			{
				sibling->Color = 1;
				node->Parent->Color = -1;
				this->RigthRotate(node->Parent);
				sibling = node->Parent->Left;
			}
			if ((sibling->Left && sibling->Right) && (sibling->Left->Color == 1 && sibling->Right && sibling->Right->Color == 1)) 
			{
				sibling->Color = -1;
				node = node->Parent;
			}
			else
			{
				if (sibling->Left && sibling->Left->Color == 1)
				{
					sibling->Right->Color =1;
					sibling->Color = -1;
					this->LeftRotatae(sibling);
					sibling = node->Parent->Left;
				}
				sibling->Color = node->Parent->Color;
				node->Parent->Color = 1;
				if (sibling->Right)
				{
					sibling->Left->Color = 1;
				}
				this->RigthRotate(node->Parent);
				node = this->Root;
			}
		}
	}
}

template<typename T>
inline void My_Red_Black<T>::InOrder(Node<T>* root, T a)
{
	if (root == nullptr)
	{
		return;
	}
	if (a == 1)
	{
		this->InOrder(root->Left, a);
		cout << root->Data << " ";
		this->InOrder(root->Right, a);
	}
	else if (a == 2)
	{
		this->InOrder(root->Right, a);
		cout << root->Data << " ";
		this->InOrder(root->Left, a);
	}
}

template<typename T>
inline void My_Red_Black<T>::PreOrder(Node<T>* root, T a)
{
	if (root == nullptr)
	{
		return;
	}
	if (a == 1)
	{
		cout << root->Data << " ";
		this->PreOrder(root->Left, a);
		this->PreOrder(root->Right, a);
	}


	else if (a == 2)
	{
		cout << root->Data << " ";
		this->PreOrder(root->Right, a);
		this->PreOrder(root->Left, a);
	}
}



template<typename T>
inline void My_Red_Black<T>::PostOrder(Node<T>* root, T a)
{
	if (root == nullptr)
	{
		return;
	}
	if (a == 1)
	{
		this->PostOrder(root->Left, a);
		this->PostOrder(root->Right, a);
		cout << root->Data << " ";
	}


	else if (a == 2)
	{
		this->PostOrder(root->Right, a);
		this->PostOrder(root->Left, a);
		cout << root->Data << " ";
	}
}
template<typename T>
inline void My_Red_Black<T>::DisplayColor(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else
	{
		cout << root->Color << " ";
		this->DisplayColor(root->Left);
		this->DisplayColor(root->Right);
	}
}
template<typename T>
inline void My_Red_Black<T>::RigthRotate(Node<T>* ptr)
{
	Node<T>* Temp = ptr->Left;
	ptr->Left = Temp->Right;
	if (Temp->Right != nullptr)
	{
		Temp->Right->Parent = ptr;
	}
	Temp->Parent = ptr->Parent;
	if (ptr->Parent == nullptr)
	{
		this->Root = Temp;
	}
	else if (ptr == ptr->Parent->Right)
	{
		ptr->Parent->Right = Temp;
	}
	else
	{
		ptr->Parent->Left = Temp;
	}
	Temp->Right = ptr;
	ptr->Parent = Temp;
}

template<typename T>
inline void My_Red_Black<T>::LeftRotatae(Node<T>* ptr)
{
	Node<T>* Temp = ptr->Right;
	ptr->Right = Temp->Left;
	if (Temp->Left != nullptr)
	{
		Temp->Left->Parent = ptr;
	}
	Temp->Parent = ptr->Parent;
	if (ptr->Parent == nullptr)
	{
		this->Root = Temp;
	}
	else if (ptr == ptr->Parent->Left)
	{
		ptr->Parent->Left = Temp;
	}
	else
	{
		ptr->Parent->Right = Temp;
	}
	Temp->Left = ptr;
	ptr->Parent = Temp;
}

template<typename T>
inline void My_Red_Black<T>::DispalyParent(T Data)
{
	if (this->Root == nullptr)
	{
		cout << "\t\t\t\t\t[ Tree is not Exixt ]" << endl;
		return;
	}
	else
	{
		if (this->SearchNode(Data) == false)
			return;
	}
	if (this->Root->Data == Data)
	{
		cout << "\t\t\t\t\t[ Its A Root Node ]" << endl;
		return;
	}
	Node<T>* temp = this->Root;
	if (temp->Data < Data)
	{
		while (temp->Right != nullptr)
		{
			temp = temp->Right;
			if (temp->Data == Data)
			{
				temp = temp->Parent;
			}
			cout << "\t\t\t\t\t[ Parent of this Node is:" << temp->Data << " ]" << endl;
			break;
		}
	}
	else if (temp->Data > Data)
	{
		while (temp->Left != nullptr)
		{
			temp = temp->Left;
			if (temp->Data == Data)
			{
				temp = temp->Parent;
			}
			cout << "\t\t\t\t\t[ Parent of this Node is:" << temp->Data << " ]" << endl;
			break;
		}
	}
}

template<typename T>
inline void My_Red_Black<T>::DeleteNode(T Data)
{
	Node<T>* delNode = this->SearchNode(this->Root, Data);
	if (delNode)
	{
		int color = delNode->Color;
		this->Root = this->DeleteNode(this->Root, Data);
		if (color == 1)
		{
			this->DeleteFix(delNode);
		}
	}
}

template<typename T>
inline void My_Red_Black<T>::Insert(T Data)
{
	this->Root = this->InsertNode(this->Root, Data);
	Node<T>* temp = this->SearchNode(this->Root, Data);
	this->InsertFix(temp);
}

template<typename T>
inline Node<T>* My_Red_Black<T>::SearchNode(Node<T>* root, T Data)
{
	if (root == nullptr)
	{
		/*cout << "\t\t\t\t\t[ No Tree is Exixt ]" << endl;*/
		return nullptr;
	}
	if (root->Data == Data)
	{
		return root;
	}
	if (root->Data > Data)
	{
		this->SearchNode(root->Left, Data);
		return root;
	}
	else 
	{
		this->SearchNode(root->Right, Data);
		return root;
	}
}

template<typename T>
inline Node<T>* My_Red_Black<T>::uncle(Node<T>* node)
{
	if (this->grandParent(node) && this->grandParent(node)->Left != node->Parent)
	{
		return this->grandParent(node)->Left;
	}
	else if (this->grandParent(node) && this->grandParent(node)->Right != node->Parent)
	{
		return this->grandParent(node)->Right;
	}
	else
	{
		return nullptr;
	}
}

template<typename T>
inline Node<T>* My_Red_Black<T>::grandParent(Node<T>* node)
{
	if (node->Parent && node->Parent->Parent)
	{
		return node->Parent->Parent;
	}
	else
	{
	return nullptr;
	}
}

template<typename T>
inline Node<T>* My_Red_Black<T>::sibling(Node<T>* node)
{
	if (node->Parent)
	{
		if (node->Parent->Right && node->Parent->Right != node)
		{
			return node->Parent->Right;
		}
		else if (node->Parent->Left && node->Parent->Left != node)
		{
			return node->Parent->Left;
		}
	}
	else
	{
		return nullptr;
	}
}
