#include"Main.h"
int main() {

	Main<int> obj;
	obj.MainOutput();

	/*My_Red_Black<int> obj;
	obj.Insert(10);
	obj.Insert(18);
	obj.Insert(7);
	obj.Insert(15);
	obj.Insert(16);
	obj.PreOrder(1);
	obj.DisplayColor();*/
	return 0;
}