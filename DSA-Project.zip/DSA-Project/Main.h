#pragma once
#include"My_Red_Black.h"
template<typename T>
class Main
{
public:
	  Main() {};
	  void MainOutput();
	  void FileRead(My_Red_Black<T>*& obj);
	 ~Main() {};
};

template<typename T>
inline void Main<T>::MainOutput()
{
	int option = 0;
	int a = 0;
	My_Red_Black<int>* obj = new My_Red_Black<int>();
	Main<int> mobj;
	do
	{
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
		cout << "\t\t\t\t\t|               DSA PROJECT 2022               |" << endl;
		cout << "\t\t\t\t\t------------------------------------------------" << endl;
		cout << "\t\t\t\t\t|          *****RED BLACK TREE*****            |" << endl;
		cout << "\t\t\t\t\t|----------------------------------------------|" << endl;
		cout << "\t\t\t\t\t|Press [1]   for Insert A Node                 |" << endl;
		cout << "\t\t\t\t\t|Press [2]   for Delete A Node                 |" << endl;
		cout << "\t\t\t\t\t|Press [3]   for Search A Node                 |" << endl;
		cout << "\t\t\t\t\t|Press [4]   for Inorder Trvasal               |" << endl;
		cout << "\t\t\t\t\t|Press [5]   for Preorder Trvasal              |" << endl;
		cout << "\t\t\t\t\t|Press [6]   for Postorder Trvasal             |" << endl;
		cout << "\t\t\t\t\t|Press [7]   for Displaying parent Of A Node   |" << endl;
		cout << "\t\t\t\t\t|Press [8]   for To Read Values From File      |" << endl;
		cout << "\t\t\t\t\t|Press [9]   for Delete All Duplicate Values   |" << endl;
		cout << "\t\t\t\t\t|Press [10]  for Destroy The Complete Tree     |" << endl;
		cout << "\t\t\t\t\t|Press [11]  for Exixt                         |" << endl;
		cout << "\t\t\t\t\t-----------------------------------------------" << endl;
		cout << "\t\t\t\t\t"; cin >> option;
		switch (option)
		{
		case 1:
			cout << "\t\t\t\t\tEnter the value:" << endl;
			cout << "\t\t\t\t\t"; cin >> a;
		    obj->Insert(a);
			system("cls");
			break;

		case 2:
			cout << "\t\t\t\t\tEnter the value:" << endl;
			cout << "\t\t\t\t\t"; cin >> a;
			obj->DeleteNode(a);
			system("cls");
			break;

		case 3:
			cout << "\t\t\t\t\tEnter the value:" << endl;
			cout << "\t\t\t\t\t"; cin >> a;
			obj->SearchNode(a);
			system("cls");
			if (obj->SearchNode(a)==true) {
				cout <<"\t\t\t\t\t[ Enter Node Is Successfully Found ]" << endl;
			}
			else {
				cout << "\t\t\t\t\t[ Enter Node Is Not Found ]" << endl;
			}
			break;

		case 4:
			cout << "\t\t\t\t\tPress [1] for LNR " << endl;
			cout << "\t\t\t\t\tPress [2] for RNL " << endl;
			cout << "\t\t\t\t\t"; cin >> a;
			system("cls");
			obj->InOrder(a);
			break;

		case 5:
			cout << "\t\t\t\t\tPress [1] for NLR " << endl;
			cout << "\t\t\t\t\tPress [2] for NRL " << endl;
			cout << "\t\t\t\t\t"; cin >> a;
			system("cls");
			obj->PreOrder(a);
			break;

		case 6:
			cout << "\t\t\t\t\tPress [1] for LRN " << endl;
			cout << "\t\t\t\t\tPress [2] for RLN " << endl;
			cout << "\t\t\t\t\t"; cin >> a;
			system("cls");
			obj->PostOrder(a);
			break;

		case 7:
			cout << "\t\t\t\t\tEnter the value:" << endl;
			cout << "\t\t\t\t\t"; cin >> a;
			system("cls");
			obj->DispalyParent(a);
			break;

		case 8:
			system("cls");
			this->FileRead(obj);
			break;


		case 9:
			cout << "\t\t\t\t\tEnter the value:" << endl;
			cout << "\t\t\t\t\t"; cin >> a;
			/*obj.DispalyParent(a);*/
			system("cls");
			break;


		case 10:
			system("cls");
			obj->ClearTree();
			cout << "\t\t\t\t\t[ Tree is Successfully Clear ]"  << endl;
			break;

		case 11:
			system("cls");
			cout << "\t\t\t\t\t[ Thanks For Coming  ]" << endl;
			cout << "\t\t\t\t\t[         .          ]" << endl;
			cout << "\t\t\t\t\t[         .          ]" << endl;
			cout << "\t\t\t\t\t[         .          ]" << endl;
			cout << "\t\t\t\t\t[         .          ]" << endl;
			cout << "\t\t\t\t\t[         .          ]" << endl;
			cout << "\t\t\t\t\t[         .          ]" << endl;
			cout << "\t\t\t\t\t[ .....THE END.....  ]" << endl;
			exit(0);


		default:
			system("cls");
			cout << "\t\t\t\t\t[ Invalid Value ]" << endl;
			break;
		}

	} while (true);
}

template<typename T>
inline void Main<T>::FileRead(My_Red_Black<T>*& obj)
{
	int v = 0;
	ifstream fin("input.txt");
	if (fin.is_open())
	{
		cout << "\t\t\t\t\t[ File is found ]" << endl;
		cout << "\t\t\t\t\t[ Read data is done ]" << endl;
		while (!fin.eof())
		{
			fin >> v;
			obj->Insert(v);
		}
		fin.close();
	}
	else
	{
		cout << "\t\t\t\t\t[ File is not Found ]" << endl;
	}
}
