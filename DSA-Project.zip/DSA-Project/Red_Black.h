#pragma once
#include<iostream>
#include<fstream>
using namespace std;
template <typename T>
class Node
{
public:
	T Data;
	T Color;
	Node<T>* Left;
	Node<T>* Right;
	Node<T>* Parent;
	Node();
	Node(T);
};
template<typename T>
inline Node<T>::Node()
{
	this->Data = 0;
	this->Color = 0;
	this->Left = nullptr;
	this->Right = nullptr;
	this->Parent = nullptr;
}

template<typename T>
inline Node<T>::Node(T d)
{
	this->Data = d;
	this->Color = 1;
	this->Left = nullptr;
	this->Right = nullptr;
	this->Parent = nullptr;
}
template <typename T>
class Red_Black
{
protected:
	Node<T>* Root;
public:
	Red_Black();
	virtual Node<T>* InsertNode(Node<T>* root, T data) = 0;
	virtual Node<T>* DeleteNode(Node<T>* root, T data) = 0;
	virtual Node<T>* SearchNode(Node<T>* root, T data) = 0;
	virtual void InOrder(Node<T>* root, T a) = 0;
	virtual void PreOrder(Node<T>* root, T a) = 0;
	virtual void PostOrder(Node<T>* root, T a) = 0;
	virtual void DispalyParent(T data) = 0;
	void ClearTree(Node<T>* root);
	void ClearTree();
	~Red_Black();
};
template<typename T>
inline Red_Black<T>::Red_Black()
{
	this->Root = nullptr;
}


template<typename T>
inline void Red_Black<T>::ClearTree(Node<T>* root)
{
	if (root == nullptr)
	{
		return;
	}
	else
	{
		this->ClearTree(root->Left);
		this->ClearTree(root->Right);
		delete root;
	}
}

template<typename T>
inline void Red_Black<T>::ClearTree()
{
	this->ClearTree(this->Root);
}


template<typename T>
inline Red_Black<T>::~Red_Black()
{
	if (this->Root != nullptr)
	{
		this->ClearTree(this->Root);
	}
}