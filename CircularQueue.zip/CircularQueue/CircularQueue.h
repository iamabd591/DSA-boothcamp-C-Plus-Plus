#pragma once
#include<iostream>
using namespace std;
template <typename T>
class CircularQueue
{
public:
	virtual void Enqueue(int) = 0;
	virtual int Dequeue() = 0;
};

