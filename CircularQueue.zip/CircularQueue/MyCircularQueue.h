#pragma once
#include"CircularQueue.h"
template<typename T>
class MyCircularQueue : public CircularQueue <T>
{
private:
	int* arr;
	int size;
	int front;
	int rear;
	int count;
public:
	MyCircularQueue();
	MyCircularQueue(int s);
	~MyCircularQueue();
	virtual void Enqueue(int);
	virtual int Dequeue();
	bool IsFull();
	bool IsEmpty();
	void Printqueue();
};
template<typename T>
MyCircularQueue<T>::MyCircularQueue() {
	this->arr = nullptr;
	this->size = 0;
	this->front = 0;
	this->rear = 0;
	this->count = 0;
}

template<typename T>
MyCircularQueue<T>::MyCircularQueue(int s) {
	this->front = -1;
	this->rear = -1;
	this->count = -1;
	this->size = s;
	this->arr = new int[this->size];
}

template<typename T>
MyCircularQueue<T>::~MyCircularQueue() {
	if (this->arr != nullptr)
	{
		delete[] this->arr;
	}
}

template<typename T>
void MyCircularQueue<T>::Enqueue(int value) {
	if (IsFull())
	{
		cout << "Queue is Already Full" << endl;
	}
	else
	{
		if (this->front == -1)
		{
			this->rear = 0;
			this->front = 0;
			this->arr[this->rear] = value;
			this->count++;
		}
		else if (this->rear == this->size - 1 && this->front != 0)
		{
			this->rear = 0;
			this->arr[this->rear] = value;
			this->count++;
		}
		else
		{
			this->rear++;
			this->arr[this->rear] = value;
			this->count++;
		}
	}
}

template<typename T>
int MyCircularQueue<T>::Dequeue() {
	int value = 0;
	if (IsEmpty())
	{
		cout << "Queue is Already Empty" << endl;
		return value;
	}
	else
	{
		value = this->arr[this->front];
		this->arr[this->front] = -1;
		if (this->front == this->rear)
		{
			this->front = -1;
			this->rear = -1;
		}
		else if (this->front == this->size - 1)
		{
			this->front = 0;
		}
		else
		{
			this->front++;
		}
		return value;

	}
}

template<typename T>
bool MyCircularQueue<T>::IsFull() {
	if ((this->front == 0 && this->rear == this->size - 1) || (this->rear == (this->front - 1) % (this->size-1)))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

template<typename T>
bool MyCircularQueue<T>::IsEmpty() {
	if (this->front == -1 && this->rear == -1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

template<typename T>
void MyCircularQueue<T>::Printqueue() {
	for (int i = 0; i <=this->count; i++)
	{
		cout << this->arr[i] << " ";
	}
	cout << endl;
}
