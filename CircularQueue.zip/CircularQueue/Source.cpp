#include"MyCircularQueue.h"
int main()
{
	MyCircularQueue<int> obj(5);
	int option = 0;
	int a = 0;
	do {
		cout << "Press 1 for EnQueue Value" << endl;
		cout << "Press 2 for deQueue Value" << endl;
		cout << "Press 3 for Full " << endl;
		cout << "Press 4 for Empty" << endl;
		cout << "Press 5 for display" << endl;
		cout << "Press 6 for Exixt" << endl;
		cin >> option;
		switch (option)
		{
		case 1:
			cout << "Enter the value:";
			cin >> a;
			obj.Enqueue(a);
			break;

		case 2:
			a = obj.Dequeue();
			cout << "DeQueue Value:" << a << endl;
			break;

		case 3:
			if (obj.IsFull() == 1)
			{
				cout << "Queue is Full" << endl;
			}
			else
			{
				cout << "Queue is not Full" << endl;
			}
			break;

		case 4:
			if (obj.IsEmpty() == 1)
			{
				cout << "Queue is Empty" << endl;
			}
			else
			{
				cout << "Queue is not Empty" << endl;
			}
			break;

		case 5:
			obj.Printqueue();
			break;

		case 6:
			exit(0);
			break;
		default:
			cout << "Invalid Value" << endl;
			break;
		}
	} while (true);
	return 0;
}