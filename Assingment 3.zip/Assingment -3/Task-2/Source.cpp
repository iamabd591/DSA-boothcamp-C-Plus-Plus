#include "MyBST.h"
int main()
{
	MyBST<int> Tree;
	int option = 0;
	int a = 0;
	do
	{
		cout << "Press 1 for Insert A Node" << endl;
		cout << "Press 2 for Delete A Node" << endl;
		cout << "Press 3 for Search A Node" << endl;
		cout << "Press 4 for Inorder Trvasal" << endl;
		cout << "Press 5 for Preorder Trvasal" << endl;
		cout << "Press 6 for Prostorder Trvasal" << endl;
		cout << "Press 7 for Level Trvasal" << endl;
		cout << "Press 8 for Exixt" << endl;
		cin >> option;
		switch (option)
		{
		case 1:
			cout << "Enter the Node Value:";
			cin >> a;
			Tree.insertNode(a);
			system("cls");
			Tree.inOrder();
			Tree.preOrder();
			Tree.postOrder();
			Tree.LeveLOrder();
			cout << endl;
			break;

		case 2:
			cout << "Enter the Node Value:";
			cin >> a;
			Tree.deleteNode(a);
			system("cls");
			Tree.inOrder();
			Tree.preOrder();
			Tree.postOrder();
			Tree.LeveLOrder();
			cout << endl;
			break;

		case 3:
			cout << "Enter the Node Value:";
			cin >> a;
			Tree.Search(a);
			system("cls");
			if (Tree.Search(a)) {
				cout << "Found It" << endl;
			}
			else {
				cout << "Not Found" << endl;
			}
			break;

		case 4:
			system("cls");
			Tree.inOrder();
			break;

		case 5:
			system("cls");
			Tree.preOrder();
			break;

		case 6:
			system("cls");
			Tree.postOrder();
			break;

		case 7:
			system("cls");
			Tree.LeveLOrder();
			break;

		case 8:
			exit(0);
			break;

		default:
			cout << "Invalid Value" << endl;
			break;
		}

	} while (true);
	return 0;
}