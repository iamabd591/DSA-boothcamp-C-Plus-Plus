#pragma once
#include"BST.h"
template <typename T>
class MyBST :public BST <T>
{
public:
	MyBST() {};
	~MyBST() {};
	void insertNode(T data) override;
	void inOrder();
	void preOrder();
	void postOrder();
	bool Search(T data);
	void deleteNode(T data);
	void LeveLOrder();
private:
	Node<T>* insertNode(Node<T>* root, T data);
	Node<T>* deleteNOde(Node<T>* root, T data);
	bool Search(Node<T>* root, T data);
	void inOrder(Node<T>* root);
	void preOrder(Node<T>* root);
	void postOrder(Node<T>* root);
	void LeveLOrder(Node<T>* root);
};

template<typename T>
inline void MyBST<T>::insertNode(T data){
	this->Root = this->insertNode(this->Root, data);
}

template<typename T>
inline void MyBST<T>::inOrder(){
	cout << "Inorder: ";
	this->inOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBST<T>::preOrder(){
	cout << "Preorder: ";
	this->preOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBST<T>::postOrder(){
	cout << "Postorder: ";
	this->postOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBST<T>::LeveLOrder(){
	cout << "Level Order:";
	this->LeveLOrder(this->Root);
	cout << endl;
}

template<typename T>
inline bool MyBST<T>::Search(T data){
	return this->Search(this->Root, data);
}

template<typename T>
inline void MyBST<T>::deleteNode(T data){
	this->Root = this->deleteNOde(this->Root, data);
}


template<typename T>
inline Node<T>* MyBST<T>::insertNode(Node<T>* root, T data){
	if (root == nullptr) {
		return new Node<T>(data);
	}
	if (root->data < data) {
		root->Right = this->insertNode(root->Right, data);
	}
	else {
		root->Left = this->insertNode(root->Left, data);
	}
	return root;
}

template<typename T>
inline bool MyBST<T>::Search(Node<T>* root, T data){
	if (root == nullptr) {
		return false;
	}
	if (root->data == data) {
		return true;
	}
	if (root->data < data) {
		return Search(root->Right, data);
	}
	else {
		return Search(root->Left, data);
	}
}
template<typename T>
inline Node<T>* MyBST<T>::deleteNOde(Node<T>* root, T data){
	if (root == nullptr) {
		return root;
	}
	if (root->data > data) {
		root->Left = this->deleteNOde(root->Left, data);
	}
	else if (root->data < data) {
		root->Right = this->deleteNOde(root->Right, data);
	}
	else
	{
		if (root->Left == nullptr && root->Right == nullptr)
		{
			delete root;
			return nullptr;
		}
		else if (root->Right == nullptr)
		{
			Node<T>* temp = root->Left;
			delete root;
			return temp;
		}
		else if (root->Left == nullptr)
		{
			Node<T>* temp = root->Right;
			delete root;
			return temp;
		}
		else {
			Node<T>* temp = root->Right;
			while (temp->Left != nullptr) {
				temp = temp->Left;
			}
			root->data = temp->data;
			root->Right = this->deleteNOde(root->Right, temp->data);
		}
	}
	return root;
}
template<typename T>
inline void MyBST<T>::inOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		this->inOrder(root->Left);
		cout << root->data << " ";
		this->inOrder(root->Right);
	}
}
template<typename T>
inline void MyBST<T>::preOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		cout << root->data << " ";
		this->preOrder(root->Left);
		this->preOrder(root->Right);
	}
}
template<typename T>
inline void MyBST<T>::postOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		this->postOrder(root->Left);
		this->postOrder(root->Right);
		cout << root->data << " ";
	}
}

template<typename T>
inline void MyBST<T>::LeveLOrder(Node<T>* root)
{
	if (root == nullptr) 
	{
		return;
	}
	else 
	{
		queue <Node<T>*> Q;
		Q.push(root);
		while (!Q.empty())
		{
			Node<T>* Current = Q.front();
			cout << Current->data << " ";
			if (Current->Left != nullptr) 
			{
				Q.push(Current->Left);
			}
			if (Current->Right != nullptr)
			{
				Q.push(Current->Right);
			}
			Q.pop();
		}
	}
}