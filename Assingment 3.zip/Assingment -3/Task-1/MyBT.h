#pragma once
#include"BT.h"
template<typename T>
class MyBT :public BT <T>
{
public:
	void InsertAtRoot(T data);
	void InsertAtSibling(T data);
	void InsertAtChild(T data);
	void inOrder();
	void preOrder();
	void postOrder();
	void LeveLOrder();
	bool Search(T data);
	bool Delete(T data);
private:
	Node<T>* InsertAtRoot(Node<T>* root, T data);
	Node<T>* InsertAtSIbling(Node<T>* root, T data);
	Node<T>* InsertAtChild(Node<T>* root, T data);
	void inOrder(Node<T>* root);
	void preOrder(Node<T>* root);
	void postOrder(Node<T>* root);
	void LeveLOrder(Node<T>* root);
	bool Delete(Node<T>* root, T data);
	bool Search(Node<T>* root, T data);
};

template<typename T>
inline void MyBT<T>::InsertAtRoot(T data)
{
	this->Root = this->InsertAtRoot(this->Root, data);
}

template<typename T>
inline void MyBT<T>::InsertAtSibling(T data)
{
	this->Root = this->InsertAtSIbling(this->Root, data);
}

template<typename T>
inline void MyBT<T>::InsertAtChild(T data)
{
	this->Root = this->InsertAtChild(this->Root, data);
}

template<typename T>
inline bool MyBT<T>::Delete(T data)
{
	return this->Delete(this->Root, data);
}

template<typename T>
inline bool MyBT<T>::Search(T data)
{
	return this->Search(this->Root, data);
}

template<typename T>
inline Node<T>* MyBT<T>::InsertAtRoot(Node<T>* root, T data)
{
	if (root == nullptr)
	{
		root = new Node<T>(data);
		return root;
	}
	else
	{
		return root;
	}

}
template<typename T>
inline void MyBT<T>::inOrder() {
	cout << "Inorder: ";
	this->inOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBT<T>::preOrder() {
	cout << "Preorder: ";
	this->preOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBT<T>::postOrder() {
	cout << "Postorder: ";
	this->postOrder(this->Root);
	cout << endl;
}

template<typename T>
inline void MyBT<T>::LeveLOrder() {
	cout << "Level Order:";
	this->LeveLOrder(this->Root);
	cout << endl;
}
template<typename T>
inline Node<T>* MyBT<T>::InsertAtSIbling(Node<T>* root, T data)
{
	if (root->RightSiblling == nullptr)
	{
		root->RightSiblling = new Node<T>(data);
		return root;
	}
	else
	{
		this->InsertAtSIbling(root->RightSiblling, data);
	}
	return root;
}

template<typename T>
inline Node<T>* MyBT<T>::InsertAtChild(Node<T>* root, T data)
{
	if (root->LeftChild == nullptr)
	{
		root->LeftChild = new Node<T>(data);
		return root;
	}
	else
	{
		this->InsertAtChild(root->LeftChild, data);
	}
	return root;
}

template<typename T>
inline bool MyBT<T>::Delete(Node<T>* root, T data)
{
	if (root == nullptr)
	{
		return false;
	}
	if (root->data == data)
	{
		this->ClearTree(root->LeftChild);
		root->LeftChild = nullptr;
		return true;
	}
	int value = this->Search(root->LeftChild, data);
	if (value==data)
	{
		this->ClearTree(root->LeftChild);
		root->LeftChild = nullptr;
		return true;
	}
	else
	{
		return false;
	}
}

template<typename T>
inline bool MyBT<T>::Search(Node<T>* root, T data)
{
	if (root == nullptr)
	{
		return false;
	}
	if (root->data == data)
	{
		return true;
	}
	if (root->LeftChild != nullptr)
	{
		return Search(root->LeftChild, data);
	}
	if(root->RightSiblling!=nullptr)
	{
		return Search(root->RightSiblling, data);
	}
}
template<typename T>
inline void MyBT<T>::inOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		this->inOrder(root->LeftChild);
		cout << root->data << " ";
		this->inOrder(root->RightSiblling);
	}
}
template<typename T>
inline void MyBT<T>::preOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		cout << root->data << " ";
		this->preOrder(root->LeftChild);
		this->preOrder(root->RightSiblling);
	}
}
template<typename T>
inline void MyBT<T>::postOrder(Node<T>* root)
{
	if (root == nullptr) {
		return;
	}
	else {
		this->postOrder(root->LeftChild);
		this->postOrder(root->RightSiblling);
		cout << root->data << " ";
	}
}
template<typename T>
inline void MyBT<T>::LeveLOrder(Node<T>* root)
{
	if (root == nullptr)
	{
		return;
	}
	else
	{
		queue <Node<T>*> Q;
		Q.push(root);
		while (!Q.empty())
		{
			Node<T>* Current = Q.front();
			cout << Current->data << " ";
			if (Current->LeftChild != nullptr)
			{
				Q.push(Current->LeftChild);
			}
			if (Current->RightSiblling != nullptr)
			{
				Q.push(Current->RightSiblling);
			}
			Q.pop();
		}
	}
}