#pragma once
#include<iostream>
#include<queue>
using namespace std;
template<typename T>
class Node {
public:
	T data;
	Node<T>* LeftChild;
	Node<T>* RightSiblling;
	Node();
	Node(T d);
};
template<typename T>
inline Node<T>::Node()
{
	this->data = 0;
	this->LeftChild = nullptr;
	this->RightSiblling = nullptr;
}

template<typename T>
inline Node<T>::Node(T d)
{
	this->data = d;
	this->LeftChild = nullptr;
	this->RightSiblling = nullptr;
}

template<typename T>
class BT
{
protected:
	Node<T>* Root;
public:
	BT();
	virtual void InsertAtRoot(T data) = 0;
	virtual void InsertAtSibling(T data) = 0;
	virtual void InsertAtChild(T data) = 0;
	virtual bool Delete(T data) = 0;
	virtual bool Search(T data) = 0;
	void ClearTree(Node<T>* root);
	~BT();

};
template<typename T>
inline BT<T>::BT()
{
	this->Root = nullptr;
}

template<typename T>
inline void BT<T>::ClearTree(Node<T>* root)
{
	if (root == nullptr)
	{
		return;
	}
	else
	{
		ClearTree(root->LeftChild);
		ClearTree(root->RightSiblling);
		delete root;
	}
}

template<typename T>
inline BT<T>::~BT()
{
	if (this->Root != nullptr)
	{
		this->ClearTree(this->Root);
	}
}
