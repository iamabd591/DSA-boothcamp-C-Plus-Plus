#pragma once
#include"dbcll.h"
template <typename T>
class Node {
public:
	int value;
	Node<T>* next;
	Node<T>* prev;
	Node();
	Node(T);
};
template <typename T>
class cdbl
{
private:
	Node<T>* head;
	Node<T>* tail;
public:
	cdbl();
	virtual	void Insert_at_first(T);
	virtual	void Insert_at_last(T);
	virtual	void Insert_at_position(T, int);
	virtual	void Delete_at_first();
	virtual	void Delete_at_last();
	virtual	void Delete_from_position(T);
	virtual	void Delete_Node(T);
	virtual void Insert_at_Mid(T);
	void Display();
	bool isEmpty();
	bool Search(T);
	int Sizeof();
	void Reverse();
	void sort();
	void Swap();
	T Sum();
	~cdbl();
};
template <typename T>
Node<T>::Node() {
	this->value = 0;
	this->next = nullptr;
	this->prev = nullptr;
}
template <typename T>
Node<T>::Node(T v) {
	this->value = v;
	this->next = nullptr;
	this->prev = nullptr;
}
template <typename T>
cdbl<T>::cdbl() {
	this->head = nullptr;
	this->tail = nullptr;
}
template <typename T>
void cdbl<T>::Insert_at_first(T v) {
	Node<T>* temp = new Node<T>(v);
	if (isEmpty()) {
		this->head = this->tail = temp;
	}
	else {
		temp->next = this->head;
		temp->prev = this->tail;
		this->head->prev = temp;
		this->head = temp;
		this->tail->next = temp;
	}
}
template <typename T>
void cdbl<T>::Insert_at_last(T v) {
	Node<T>* temp = new Node<T>(v);
	if (isEmpty())
	{
		this->head = this->tail = temp;
		return;
	}
	this->tail->next = temp;
	temp->prev = this->tail;
	this->tail = temp;
	this->tail->next = this->head;
	this->head->prev = this->tail;
}
template <typename T>
void cdbl<T>::Insert_at_position(T v, int pos) {
	int s = this->Sizeof();
	if (pos == 1)
	{
		Insert_at_first(v);
		return;
	}
	Node<T>* newNode = new Node<T>(v);
	if (pos == s)
	{
		/*newNode->next = this->tail;
		newNode->prev = this->tail->prev;
		this->tail->prev->next = newNode;
		this->tail->prev = newNode;*/
		this->Insert_at_last(v);
		return;
	}
	Node<T>* itr = this->head->next;
	while (pos > 2)
	{
		itr = itr->next;
		pos--;
	}
	newNode->next = itr;
	newNode->prev = itr->prev;
	itr->prev->next = newNode;
	itr->prev = newNode;
}
template <typename T>
void cdbl<T>::Delete_at_first() {
	if (isEmpty())
	{
		cout << "List is Empty" << endl;
		return;
	}
	Node<T>* temp = this->head;
	if (this->head == this->tail)
	{
		this->head = this->tail = nullptr;
		delete temp;
		return;
	}
	this->head = this->head->next;
	this->head->prev = this->tail;
	this->tail->next = this->head;
	delete temp;
}
template <typename T>
void cdbl<T>::Delete_at_last() {
	if (isEmpty())
	{
		cout << "List is Empty" << endl;
		return;
	}
	Node<T>* temp = this->tail;
	if (this->head == this->tail)
	{
		this->head = this->tail = nullptr;
		delete temp;
		return;
	}
	this->tail = this->tail->prev;
	this->tail->next = this->head;
	this->head->prev = this->tail;
	delete temp;
}
template <typename T>
void cdbl<T>::Delete_from_position(T i) {
	if (this->head == nullptr)
		return;
	if (i == 0)
	{
		this->Delete_at_first();
		return;
	}
	if (i == this->Sizeof() - 1)
	{
		this->Delete_at_last();
		return;
	}
	Node<T>* itr = this->head->next;
	while (i >= 2)
	{
		itr = itr->next;
		i--;
	}
	Node<T>* temp = itr;
	itr->prev->next = itr->next;
	itr->next->prev = itr->prev;
	itr = itr->prev;
	delete temp;
}
template <typename T>
void cdbl<T>::Delete_Node(T v) {
	Node<T>* temp = new Node<T>();
	temp = this->head;
	bool found = false;
	int i = 0;
	while (temp != nullptr)
	{
		if (temp->value == v)
		{
			found = true;
			break;
		}
		temp = temp->next;
		i++;
	}
	if (found)
	{
		Delete_from_position(i);

	}
	else
	{
		cout << "Value can not found" << endl;
	}
}
template <typename T>
void cdbl<T>::Insert_at_Mid(T v) {
	int s = Sizeof() / 2;
	this->Insert_at_position(v, ++s);
}
template <typename T>
void cdbl<T>::Display() {
	if (this->isEmpty())
	{
		cout << "List is empty" << endl;
		return;
	}
	Node<T>* temp = this->head;
	cout << "Double Circular Linked List:";
	while (temp->next!= this->head)
	{
		cout << temp->value << "->";
		temp = temp->next;
	}
	cout << temp->value;
	cout << endl;
}
template <typename T>
bool cdbl<T>::isEmpty() {
	if (this->head == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
template <typename T>
bool cdbl<T>::Search(T v) {
	Node<T>* temp = this->head;
	bool found = true;
	while (temp->next != this->head)
	{
		if (temp->value == v)
		{
			found = true;
			break;
		}
		else
		{
			found = false;
			break;
		}
		temp = temp->next;
	}
	if (found)
	{
		cout << "Node " << v << " is Found" << endl;
		return true;
	}
	else
	{
		cout << "Node " << v << " is Not Found" << endl;
		return false;
	}
}
template <typename T>
int cdbl<T>::Sizeof() {
	int count = 0;
	if (isEmpty())
	{
		return count;
	}
	else
	{
		Node<T>* temp = this->head;
		while (temp->next != this->head)
		{
			temp = temp->next;
			count++;
		}
		return ++count;
	}
}
template <typename T>
void cdbl<T>::Reverse() {
	if (this->isEmpty())
	{
		cout << "List is empty" << endl;
		return;
	}
	cout << "Reverse Double Linked List: ";
	Node<T>* temp = this->tail;
	/*cout << temp->value << "->";*/
	while (temp->prev!= this->tail)
	{
		cout << temp->value << "->";
		temp = temp->prev;
	}
	cout << temp->value;
	cout << endl;

	/*Node<T>* itr = this->tail;
	do
	{
		cout << itr->value;
		if (itr->prev != nullptr)
			itr = itr->prev;
		else
			break;
		if (itr != this->tail)
			cout << "-->";
	} while (itr != this->tail);
	cout << endl;*/
}
template <typename T>
void cdbl<T>::sort() {
	Node<T>* temp1 = this->head;
	Node<T>* temp2 = new Node<T>();
	Node<T>* temp3 = new Node<T>();
	while (temp1->next != this->tail)
	{
		temp2 = temp1->next;
		while (temp2 != this->tail)
		{
			if (temp2->value < temp1->value)
			{
				temp3->value = temp1->value;
				temp1->value = temp2->value;
				temp2->value = temp3->value;
			}
			temp2 = temp2->next;
		}
		temp1 = temp1->next;
	}
}
template <typename T>
T cdbl<T>::Sum() {
	T sum = 0;
	if (isEmpty())
	{
		cout << "List is Empty" << endl;
		return sum;
	}
	else
	{
		Node<T>* temp = this->head;
		while (temp->next != this->head)
		{
			sum += temp->value;
			temp= temp->next;
		}
		sum += temp->value;
		return sum;
	}
}
template <typename T>
void cdbl<T>::Swap() {
	Node<T>* temp = this->tail->prev;
	temp->next->next = this->head->next;
	this->head->next = temp->next;
	temp->next = this->head;
	this->head = this->head->next;
}
template <typename T>
cdbl<T>::~cdbl() {
	Node<T>* temp = this->head;
	while (temp != this->head)
	{
		this->head = this->head->next;
		delete temp;
		temp = this->head;
	}
	delete temp;
}