#include"cdbl.h"
int main()
{
	cdbl<int> obj;
	obj.Insert_at_first(10);
	obj.Insert_at_first(9);
	obj.Insert_at_first(8);
	obj.Insert_at_first(7);
	obj.Insert_at_first(6);
	obj.Insert_at_first(5);
	obj.Insert_at_first(4);
	obj.Insert_at_first(3);
	obj.Insert_at_first(2);
	obj.Insert_at_first(1);
	obj.Insert_at_last(11);
	obj.Insert_at_last(12);
	obj.Insert_at_last(13);
	obj.Insert_at_last(14);
	obj.Insert_at_Mid(10);
	obj.Display();
	obj.Delete_at_first();
	obj.Delete_at_last();
	obj.Delete_from_position(11);
	obj.Delete_Node(10);
	cout << "----------------------------------------------------" << endl;
	obj.Display();
	cout << "----------------------------------------------------" << endl;
	obj.Reverse();
	cout << "----------------------------------------------------" << endl;
	cout << "Sort ";
	obj.sort();
	obj.Display();
	cout << "----------------------------------------------------" << endl;
	obj.Search(22);
	cout << "----------------------------------------------------" << endl;
	cout << "Swap ";
	obj.Swap();
	obj.Display();
	cout << "----------------------------------------------------" << endl;
	cout << "Sum of Lisnked List:" << obj.Sum() << endl;
	cout << "----------------------------------------------------" << endl;
	cout << "Size of List:" << obj.Sizeof() << endl;
	return 0;
}